import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bell, Clock, Heart, CheckCircle, X, Calendar } from "lucide-react";
import { format, isToday, isTomorrow, addHours } from "date-fns";
import { ptBR } from "date-fns/locale";

interface Notification {
  id: string;
  type: "appointment" | "reminder" | "update" | "promo";
  title: string;
  message: string;
  time: Date;
  read: boolean;
  appointmentId?: string;
}

interface NotificationCenterProps {
  appointments: Array<{
    id: string;
    pet: string;
    service: string;
    date: string;
    time: string;
    status: string;
  }>;
}

const NotificationCenter = ({ appointments }: NotificationCenterProps) => {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "1",
      type: "reminder",
      title: "Lembrete de Consulta",
      message: "Consulta do Rex amanhã às 10:00",
      time: new Date(),
      read: false,
      appointmentId: "1"
    },
    {
      id: "2",
      type: "appointment",
      title: "Agendamento Confirmado",
      message: "Banho e tosa da Mimi confirmado para hoje às 14:30",
      time: addHours(new Date(), -2),
      read: false,
      appointmentId: "2"
    },
    {
      id: "3",
      type: "update",
      title: "Serviço Concluído",
      message: "Vacinação do Rex foi concluída com sucesso",
      time: addHours(new Date(), -5),
      read: true,
      appointmentId: "3"
    },
    {
      id: "4",
      type: "promo",
      title: "Promoção Especial",
      message: "20% de desconto em banho e tosa neste mês!",
      time: addHours(new Date(), -24),
      read: false
    }
  ]);

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "appointment":
        return <Calendar className="h-4 w-4" />;
      case "reminder":
        return <Bell className="h-4 w-4" />;
      case "update":
        return <CheckCircle className="h-4 w-4" />;
      case "promo":
        return <Heart className="h-4 w-4" />;
      default:
        return <Bell className="h-4 w-4" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "appointment":
        return "bg-blue-100 text-blue-800";
      case "reminder":
        return "bg-yellow-100 text-yellow-800";
      case "update":
        return "bg-green-100 text-green-800";
      case "promo":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getTimeLabel = (time: Date) => {
    if (isToday(time)) {
      return `Hoje às ${format(time, "HH:mm")}`;
    } else if (isTomorrow(time)) {
      return `Amanhã às ${format(time, "HH:mm")}`;
    } else {
      return format(time, "dd/MM 'às' HH:mm", { locale: ptBR });
    }
  };

  const markAsRead = (id: string) => {
    setNotifications(notifications.map(notif => 
      notif.id === id ? { ...notif, read: true } : notif
    ));
  };

  const removeNotification = (id: string) => {
    setNotifications(notifications.filter(notif => notif.id !== id));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Bell className="h-5 w-5 mr-2" />
            Notificações
          </div>
          {unreadCount > 0 && (
            <Badge variant="destructive" className="ml-2">
              {unreadCount}
            </Badge>
          )}
        </CardTitle>
        <CardDescription>
          Acompanhe suas notificações e lembretes
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {notifications.length === 0 ? (
            <div className="text-center py-8">
              <Bell className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">Nenhuma notificação</p>
            </div>
          ) : (
            notifications.map((notification) => (
              <div
                key={notification.id}
                className={`flex items-start space-x-3 p-3 rounded-lg border ${
                  notification.read ? "bg-background" : "bg-muted/30"
                }`}
              >
                <div className={`p-2 rounded-full ${getNotificationColor(notification.type)}`}>
                  {getNotificationIcon(notification.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className={`text-sm font-medium ${
                      notification.read ? "text-muted-foreground" : "text-foreground"
                    }`}>
                      {notification.title}
                    </p>
                    <div className="flex items-center space-x-1">
                      {!notification.read && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => markAsRead(notification.id)}
                          className="h-6 w-6 p-0"
                        >
                          <CheckCircle className="h-3 w-3" />
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeNotification(notification.id)}
                        className="h-6 w-6 p-0"
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {notification.message}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1 flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    {getTimeLabel(notification.time)}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default NotificationCenter;
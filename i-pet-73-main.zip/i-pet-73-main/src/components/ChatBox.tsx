
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MessageCircle, Clock, Phone } from 'lucide-react';

export function ChatBox() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simular envio (aqui você integraria com seu backend)
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    console.log('Dados do formulário:', formData);
    
    // Reset form
    setFormData({ name: '', email: '', message: '' });
    setIsSubmitting(false);
    
    // Mostrar feedback de sucesso
    alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');
  };

  const handleWhatsApp = () => {
    const message = encodeURIComponent(
      `Olá! Tenho interesse no I-Pet e gostaria de saber mais informações sobre o sistema.`
    );
    window.open(`https://wa.me/5511999999999?text=${message}`, '_blank');
  };

  return (
    <Card className="border-border/50 shadow-medium">
      <CardHeader className="text-center">
        <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
          <MessageCircle className="h-6 w-6 text-white" />
        </div>
        <CardTitle className="text-2xl text-foreground">
          Ainda tem dúvidas?
        </CardTitle>
        <p className="text-muted-foreground">
          Fale conosco agora mesmo e receba atendimento personalizado
        </p>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Horário de Atendimento */}
        <div className="flex items-center gap-3 text-sm text-muted-foreground bg-muted/50 p-3 rounded-lg">
          <Clock className="h-4 w-4" />
          <span>Atendimento: Segunda a Sexta, 8h às 18h</span>
        </div>

        {/* Formulário */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            placeholder="Seu nome"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            required
          />
          
          <Input
            type="email"
            placeholder="Seu e-mail"
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
            required
          />
          
          <Textarea
            placeholder="Como podemos ajudar você?"
            value={formData.message}
            onChange={(e) => setFormData({...formData, message: e.target.value})}
            rows={4}
            required
          />
          
          <Button 
            type="submit" 
            className="w-full" 
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Enviando...' : 'Enviar Mensagem'}
          </Button>
        </form>

        {/* Separador */}
        <div className="flex items-center gap-4">
          <div className="flex-1 border-t border-border"></div>
          <span className="text-xs text-muted-foreground">OU</span>
          <div className="flex-1 border-t border-border"></div>
        </div>

        {/* WhatsApp */}
        <Button 
          onClick={handleWhatsApp}
          variant="outline" 
          className="w-full border-green-500 text-green-600 hover:bg-green-50 hover:text-green-700"
        >
          <Phone className="mr-2 h-4 w-4" />
          Falar no WhatsApp
        </Button>
      </CardContent>
    </Card>
  );
}

import React, { useState } from 'react';
import CalendarView from './CalendarView';
import ServiceScheduleView from './ServiceScheduleView';
import { Appointment } from '@/hooks/useAppointments';
import { Button } from '@/components/ui/button';
import { Calendar, Grid3X3 } from 'lucide-react';
interface AppointmentViewsProps {
  appointments: Appointment[];
  filteredAppointments: Appointment[];
  selectedDate: Date;
  onDateChange: (date: Date) => void;
  availableSlots: string[];
  searchQuery: string;
  onSearch: (query: string) => void;
  onStatusChange: (id: number, status: string) => void;
  onEdit: (id: number) => void;
  onDelete: (id: number) => void;
  onSelectAppointment?: (appointment: Appointment) => void;
  onSelectSlot?: (time: string) => void;
  onReorderAppointments?: (appointments: Appointment[]) => void;
}
const AppointmentViews = ({
  appointments,
  filteredAppointments,
  selectedDate,
  onDateChange,
  availableSlots,
  searchQuery,
  onSearch,
  onStatusChange,
  onEdit,
  onDelete,
  onSelectAppointment,
  onSelectSlot,
  onReorderAppointments
}: AppointmentViewsProps) => {
  const [viewMode, setViewMode] = useState<'calendar' | 'schedule'>('schedule');
  const handleCalendarEventSelect = (event: any) => {
    if (onSelectAppointment) {
      onSelectAppointment(event.resource);
    }
  };
  const handleCalendarSlotSelect = (slotInfo: any) => {
    if (onSelectSlot) {
      const time = slotInfo.start.toLocaleTimeString('pt-BR', {
        hour: '2-digit',
        minute: '2-digit'
      });
      onSelectSlot(time);
    }
  };
  const handleServiceSlotSelect = (time: string, service: string) => {
    if (onSelectSlot) {
      onSelectSlot(time);
    }
  };
  return <div className="space-y-4">
      {/* View Toggle */}
      <div className="flex gap-2">
        <Button variant={viewMode === 'schedule' ? 'default' : 'outline'} size="sm" onClick={() => setViewMode('schedule')} className="flex items-center gap-2">
          <Grid3X3 className="h-4 w-4" />
          Agenda por Serviços
        </Button>
        
      </div>

      {/* Content based on view mode */}
      {viewMode === 'schedule' ? <ServiceScheduleView appointments={appointments} selectedDate={selectedDate} onDateChange={onDateChange} onSelectSlot={handleServiceSlotSelect} onSelectAppointment={onSelectAppointment} onStatusChange={onStatusChange} onEdit={onEdit} onDelete={onDelete} /> : <CalendarView appointments={appointments} onSelectEvent={handleCalendarEventSelect} onSelectSlot={handleCalendarSlotSelect} selectedDate={selectedDate} onStatusChange={onStatusChange} onEdit={onEdit} onDelete={onDelete} />}
    </div>;
};
export default AppointmentViews;
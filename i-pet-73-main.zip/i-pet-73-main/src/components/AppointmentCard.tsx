import { Clock, User, Heart, Edit, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Appointment {
  id: number;
  time: string;
  client: string;
  pet: string;
  breed: string;
  service: string;
  status: string;
  phone: string;
  notes: string;
}

interface AppointmentCardProps {
  appointment: Appointment;
  onStatusChange: (id: number, status: string) => void;
  onEdit: (id: number) => void;
  onDelete: (id: number) => void;
}

const AppointmentCard = ({ appointment, onStatusChange, onEdit, onDelete }: AppointmentCardProps) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmado": return "bg-success/20 text-success border-success/30";
      case "em_andamento": return "bg-warning/20 text-warning border-warning/30";
      case "pendente": return "bg-destructive/20 text-destructive border-destructive/30";
      case "agendado": return "bg-primary/20 text-primary border-primary/30";
      default: return "bg-muted text-muted-foreground border-border";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "confirmado": return "✅";
      case "em_andamento": return "🔄";
      case "pendente": return "⏳";
      case "agendado": return "📅";
      default: return "";
    }
  };

  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-6 rounded-lg border border-border hover:bg-muted/30 transition-all duration-200 hover:shadow-soft">
      <div className="flex items-start gap-4 flex-1">
        <div className="text-center min-w-16">
          <div className="text-xl font-bold text-primary">{appointment.time}</div>
          <Clock className="h-4 w-4 text-muted-foreground mx-auto mt-1" />
        </div>
        
        <div className="flex-1 space-y-2">
          <div className="flex items-center gap-2">
            <User className="h-4 w-4 text-muted-foreground" />
            <span className="font-semibold">{appointment.client}</span>
            <span className="text-sm text-muted-foreground">• {appointment.phone}</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Heart className="h-4 w-4 text-accent" />
            <span className="font-medium">{appointment.pet}</span>
            <span className="text-sm text-muted-foreground">({appointment.breed})</span>
          </div>
          
          <div className="text-sm font-medium text-secondary">
            {appointment.service}
          </div>
          
          {appointment.notes && (
            <div className="text-sm text-muted-foreground">
              📝 {appointment.notes}
            </div>
          )}
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 mt-4 sm:mt-0">
        <Badge 
          variant="outline" 
          className={`${getStatusColor(appointment.status)} min-w-32 justify-center`}
        >
          {getStatusIcon(appointment.status)} {appointment.status.replace('_', ' ')}
        </Badge>
        
        <div className="flex items-center gap-2">
          <Select
            value={appointment.status}
            onValueChange={(value) => onStatusChange(appointment.id, value)}
          >
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="confirmado">Confirmado</SelectItem>
              <SelectItem value="em_andamento">Em Andamento</SelectItem>
              <SelectItem value="pendente">Pendente</SelectItem>
              <SelectItem value="agendado">Agendado</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" size="sm" onClick={() => onEdit(appointment.id)}>
            <Edit className="h-4 w-4 mr-1" />
            Editar
          </Button>
          
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onDelete(appointment.id)}
            className="text-destructive hover:text-destructive hover:bg-destructive/10"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AppointmentCard;
import React, { useMemo, useState } from 'react';
import { format, isSameDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronLeft, ChevronRight, Calendar, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Appointment } from '@/hooks/useAppointments';

interface ServiceScheduleViewProps {
  appointments: Appointment[];
  selectedDate: Date;
  onDateChange: (date: Date) => void;
  onSelectSlot?: (time: string, service: string) => void;
  onSelectAppointment?: (appointment: Appointment) => void;
  onStatusChange?: (id: number, status: string) => void;
  onEdit?: (id: number) => void;
  onDelete?: (id: number) => void;
}

const services = [
  { 
    id: 'consulta-veterinaria', 
    name: 'Consulta Veterinária',
    category: 'consultas',
    color: 'bg-blue-100 border-blue-300 text-blue-800 dark:bg-blue-900 dark:border-blue-700 dark:text-blue-200'
  },
  { 
    id: 'banho-tosa', 
    name: 'Banho e Tosa',
    category: 'estetica',
    color: 'bg-green-100 border-green-300 text-green-800 dark:bg-green-900 dark:border-green-700 dark:text-green-200'
  },
  { 
    id: 'vacinacao', 
    name: 'Vacinação',
    category: 'procedimentos',
    color: 'bg-purple-100 border-purple-300 text-purple-800 dark:bg-purple-900 dark:border-purple-700 dark:text-purple-200'
  },
  { 
    id: 'exames', 
    name: 'Exames',
    category: 'consultas',
    color: 'bg-cyan-100 border-cyan-300 text-cyan-800 dark:bg-cyan-900 dark:border-cyan-700 dark:text-cyan-200'
  },
  { 
    id: 'tosa', 
    name: 'Tosa',
    category: 'estetica',
    color: 'bg-emerald-100 border-emerald-300 text-emerald-800 dark:bg-emerald-900 dark:border-emerald-700 dark:text-emerald-200'
  },
  { 
    id: 'cirurgia', 
    name: 'Cirurgia',
    category: 'procedimentos',
    color: 'bg-red-100 border-red-300 text-red-800 dark:bg-red-900 dark:border-red-700 dark:text-red-200'
  }
];

const timeSlots = [
  '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', 
  '14:00', '15:00', '16:00', '17:00', '18:00'
];

const ServiceScheduleView = ({
  appointments,
  selectedDate,
  onDateChange,
  onSelectSlot,
  onSelectAppointment,
  onStatusChange,
  onEdit,
  onDelete
}: ServiceScheduleViewProps) => {
  const dayAppointments = useMemo(() => {
    return appointments.filter(appointment => 
      isSameDay(new Date(appointment.date), selectedDate)
    );
  }, [appointments, selectedDate]);

  const getAppointmentForSlot = (time: string, serviceId: string) => {
    return dayAppointments.find(appointment => 
      appointment.time === time && appointment.service === services.find(s => s.id === serviceId)?.name
    );
  };

  const handlePrevDay = () => {
    const prevDay = new Date(selectedDate);
    prevDay.setDate(prevDay.getDate() - 1);
    onDateChange(prevDay);
  };

  const handleNextDay = () => {
    const nextDay = new Date(selectedDate);
    nextDay.setDate(nextDay.getDate() + 1);
    onDateChange(nextDay);
  };

  const handleSlotClick = (time: string, serviceName: string) => {
    const appointment = getAppointmentForSlot(time, services.find(s => s.name === serviceName)?.id || '');
    if (appointment) {
      onSelectAppointment?.(appointment);
    } else {
      onSelectSlot?.(time, serviceName);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'agendado':
        return 'bg-blue-500';
      case 'confirmado':
        return 'bg-green-500';
      case 'em-andamento':
        return 'bg-yellow-500';
      case 'concluido':
        return 'bg-purple-500';
      case 'cancelado':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-4">
      {/* Header with navigation */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="outline" size="sm" onClick={handlePrevDay}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                <CardTitle>
                  Agenda - {format(selectedDate, 'dd/MM/yyyy', { locale: ptBR })}
                </CardTitle>
              </div>
              
              <Button variant="outline" size="sm" onClick={handleNextDay}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="flex items-center gap-2">
              <Badge variant="outline">
                {dayAppointments.length} agendamentos
              </Badge>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-1" />
                Fazer Agendamento
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Schedule Grid */}
      <Card>
        <CardContent className="p-0">
          <div className="grid grid-cols-[100px_repeat(6,1fr)] gap-0 border-b">
            {/* Header row */}
            <div className="p-3 bg-muted border-r font-semibold text-center">
              Horário
            </div>
            {services.map((service) => (
              <div key={service.id} className="p-3 bg-muted border-r font-semibold text-center text-sm">
                {service.name}
              </div>
            ))}
            
            {/* Time slots rows */}
            {timeSlots.map((time) => (
              <React.Fragment key={time}>
                <div className="p-3 border-r border-b bg-muted/50 font-medium text-center text-sm">
                  {time}
                </div>
                {services.map((service) => {
                  const appointment = getAppointmentForSlot(time, service.id);
                  
                  return (
                    <div
                      key={`${time}-${service.id}`}
                      className={cn(
                        "p-2 border-r border-b min-h-[60px] cursor-pointer hover:bg-muted/50 transition-colors",
                        "flex items-center justify-center"
                      )}
                      onClick={() => handleSlotClick(time, service.name)}
                    >
                      {appointment ? (
                        <div className={cn(
                          "w-full p-2 rounded-md border-2 text-xs relative",
                          service.color
                        )}>
                          <div className="font-semibold truncate">
                            {appointment.client}
                          </div>
                          <div className="text-xs opacity-80 truncate">
                            {appointment.pet}
                          </div>
                          <div className={cn(
                            "absolute top-1 right-1 w-2 h-2 rounded-full",
                            getStatusColor(appointment.status)
                          )} />
                          
                          {/* Action buttons on hover */}
                          <div className="absolute inset-0 bg-black/5 opacity-0 hover:opacity-100 transition-opacity rounded-md flex items-center justify-center gap-1">
                            <Button
                              size="sm"
                              variant="secondary"
                              className="h-6 px-2 text-xs"
                              onClick={(e) => {
                                e.stopPropagation();
                                onEdit?.(appointment.id);
                              }}
                            >
                              Editar
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              className="h-6 px-2 text-xs"
                              onClick={(e) => {
                                e.stopPropagation();
                                onDelete?.(appointment.id);
                              }}
                            >
                              Excluir
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-muted-foreground text-xs">
                          <Plus className="h-4 w-4" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </React.Fragment>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Legend */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-500" />
              <span>Agendado</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <span>Confirmado</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <span>Em Andamento</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-purple-500" />
              <span>Concluído</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <span>Cancelado</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ServiceScheduleView;
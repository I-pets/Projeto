import React from 'react';
import { Clock, User, Phone, FileText, MoreVertical, Edit, Trash2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Appointment } from '@/hooks/useAppointments';

interface StaffAppointmentCardProps {
  appointment: Appointment;
  index: number;
  onStatusChange?: (id: number, status: string) => void;
  onEdit?: (id: number) => void;
  onDelete?: (id: number) => void;
}

const statusConfig = {
  confirmado: { label: 'Confirmado', color: 'bg-success text-success-foreground' },
  em_andamento: { label: 'Em Andamento', color: 'bg-warning text-warning-foreground' },
  pendente: { label: 'Pendente', color: 'bg-destructive text-destructive-foreground' },
  agendado: { label: 'Agendado', color: 'bg-secondary text-secondary-foreground' }
};

const StaffAppointmentCard = ({
  appointment,
  index,
  onStatusChange,
  onEdit,
  onDelete
}: StaffAppointmentCardProps) => {
  const statusInfo = statusConfig[appointment.status as keyof typeof statusConfig];

  return (
    <Card className="transition-all duration-200 hover:shadow-md">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 space-y-2">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" />
                <span className="font-semibold text-foreground">{appointment.time}</span>
              </div>
              <Badge className={statusInfo.color}>
                {statusInfo.label}
              </Badge>
            </div>

            {/* Client and Pet */}
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium text-foreground">{appointment.client}</span>
              </div>
              <div className="text-sm text-muted-foreground ml-6">
                {appointment.pet} ({appointment.breed})
              </div>
            </div>

            {/* Service */}
            <div className="text-sm font-medium text-primary">
              {appointment.service}
            </div>

            {/* Staff */}
            <div className="flex items-center gap-2 text-sm">
              <User className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">
                Responsável: <span className="font-medium text-foreground">{appointment.staff}</span>
              </span>
            </div>

            {/* Phone */}
            {appointment.phone && (
              <div className="flex items-center gap-2 text-sm">
                <Phone className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">{appointment.phone}</span>
              </div>
            )}

            {/* Notes */}
            {appointment.notes && (
              <div className="flex items-start gap-2 text-sm">
                <FileText className="h-3 w-3 text-muted-foreground mt-0.5" />
                <span className="text-muted-foreground">{appointment.notes}</span>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-2">
            {/* Status Selector */}
            <Select
              value={appointment.status}
              onValueChange={(status) => onStatusChange?.(appointment.id, status)}
            >
              <SelectTrigger className="w-32 h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="agendado">Agendado</SelectItem>
                <SelectItem value="confirmado">Confirmado</SelectItem>
                <SelectItem value="em_andamento">Em Andamento</SelectItem>
                <SelectItem value="pendente">Pendente</SelectItem>
              </SelectContent>
            </Select>

            {/* Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onEdit?.(appointment.id)}>
                  <Edit className="mr-2 h-4 w-4" />
                  Editar
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={() => onDelete?.(appointment.id)}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Excluir
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default StaffAppointmentCard;
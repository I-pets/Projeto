import React, { useMemo, useState } from 'react';
import { Calendar as BigCalendar, dateFnsLocalizer, Views } from 'react-big-calendar';
import { format, parse, startOfWeek, getDay, isSameDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, Stethoscope, Scissors, Syringe } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Appointment } from '@/hooks/useAppointments';
import StaffAppointmentCard from './StaffAppointmentCard';
import 'react-big-calendar/lib/css/react-big-calendar.css';

const locales = {
  'pt-BR': ptBR,
};

const localizer = dateFnsLocalizer({
  format,
  parse,
  startOfWeek,
  getDay,
  locales,
});

interface CalendarViewProps {
  appointments: Appointment[];
  onSelectEvent?: (event: any) => void;
  onSelectSlot?: (slotInfo: any) => void;
  selectedDate?: Date;
  onStatusChange?: (id: number, status: string) => void;
  onEdit?: (id: number) => void;
  onDelete?: (id: number) => void;
}

const serviceCategories = {
  consultas: {
    title: '🏥 Consultas e Exames',
    icon: Stethoscope,
    color: 'bg-blue-50 border-blue-200 dark:bg-blue-950 dark:border-blue-800',
    services: ['Consulta Veterinária', 'Consulta + Exames', 'Exames']
  },
  estetica: {
    title: '🛁 Estética e Higiene',
    icon: Scissors,
    color: 'bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800',
    services: ['Banho e Tosa', 'Tosa', 'Banho']
  },
  procedimentos: {
    title: '💉 Procedimentos Médicos',
    icon: Syringe,
    color: 'bg-purple-50 border-purple-200 dark:bg-purple-950 dark:border-purple-800',
    services: ['Vacinação', 'Cirurgia', 'Castração']
  }
};

const CalendarView = ({ 
  appointments, 
  onSelectEvent, 
  onSelectSlot, 
  selectedDate, 
  onStatusChange, 
  onEdit, 
  onDelete 
}: CalendarViewProps) => {
  const [currentSelectedDate, setCurrentSelectedDate] = useState<Date>(selectedDate || new Date());

  const events = useMemo(() => {
    return appointments.map(appointment => {
      const [hours, minutes] = appointment.time.split(':').map(Number);
      const startDate = new Date(appointment.date);
      startDate.setHours(hours, minutes, 0, 0);
      
      const endDate = new Date(startDate);
      endDate.setHours(hours + 1, minutes, 0, 0);

      return {
        id: appointment.id,
        title: `${appointment.client} - ${appointment.pet}`,
        start: startDate,
        end: endDate,
        resource: appointment,
      };
    });
  }, [appointments]);

  const dayAppointments = useMemo(() => {
    return appointments.filter(appointment => 
      isSameDay(new Date(appointment.date), currentSelectedDate)
    );
  }, [appointments, currentSelectedDate]);

  const getAppointmentsByCategory = (category: keyof typeof serviceCategories) => {
    return dayAppointments.filter(appointment => 
      appointment.serviceCategory === category
    ).sort((a, b) => a.time.localeCompare(b.time));
  };

  const handleDateSelect = (date: Date) => {
    setCurrentSelectedDate(date);
    if (onSelectSlot) {
      onSelectSlot({ start: date });
    }
  };

  return (
    <div className="space-y-6">
      {/* Calendar for date selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-primary" />
            Selecionar Data
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div style={{ height: 400 }}>
            <BigCalendar
              localizer={localizer}
              events={events}
              startAccessor="start"
              endAccessor="end"
              style={{ height: '100%' }}
              onSelectEvent={onSelectEvent}
              onSelectSlot={(slotInfo) => handleDateSelect(slotInfo.start)}
              onNavigate={(date) => setCurrentSelectedDate(date)}
              selectable
              defaultView={Views.MONTH}
              views={[Views.MONTH]}
              culture="pt-BR"
              className={cn(
                '[&_.rbc-calendar]:bg-background',
                '[&_.rbc-header]:bg-muted/50 [&_.rbc-header]:text-foreground [&_.rbc-header]:border-border',
                '[&_.rbc-today]:bg-primary/10',
                '[&_.rbc-off-range-bg]:bg-muted/20',
                '[&_.rbc-toolbar]:mb-4',
                '[&_.rbc-toolbar-label]:text-lg [&_.rbc-toolbar-label]:font-semibold',
                '[&_.rbc-btn-group]:space-x-1',
                '[&_.rbc-btn-group_button]:px-3 [&_.rbc-btn-group_button]:py-1 [&_.rbc-btn-group_button]:rounded-md [&_.rbc-btn-group_button]:border [&_.rbc-btn-group_button]:border-border [&_.rbc-btn-group_button]:bg-background [&_.rbc-btn-group_button]:text-foreground [&_.rbc-btn-group_button]:hover:bg-muted',
                '[&_.rbc-active]:bg-primary [&_.rbc-active]:text-primary-foreground [&_.rbc-active]:border-primary'
              )}
            />
          </div>
        </CardContent>
      </Card>

      {/* Day view with categories */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-primary" />
            Agendamentos para {format(currentSelectedDate, 'dd/MM/yyyy', { locale: ptBR })}
            <Badge variant="outline" className="ml-2">
              {dayAppointments.length} agendamentos
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {Object.entries(serviceCategories).map(([categoryKey, category]) => {
              const categoryAppointments = getAppointmentsByCategory(categoryKey as keyof typeof serviceCategories);
              
              return (
                <div key={categoryKey} className={cn("rounded-lg border-2 p-4", category.color)}>
                  <div className="flex items-center gap-2 mb-4">
                    <category.icon className="h-5 w-5" />
                    <h3 className="font-semibold">{category.title}</h3>
                    <Badge variant="secondary" className="ml-auto">
                      {categoryAppointments.length}
                    </Badge>
                  </div>
                  
                  <div className="space-y-3">
                    {categoryAppointments.length === 0 ? (
                      <div className="text-center text-muted-foreground py-8">
                        Nenhum agendamento
                      </div>
                    ) : (
                      categoryAppointments.map((appointment, index) => (
                        <StaffAppointmentCard
                          key={appointment.id}
                          appointment={appointment}
                          index={index}
                          onStatusChange={onStatusChange}
                          onEdit={onEdit}
                          onDelete={onDelete}
                        />
                      ))
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CalendarView;
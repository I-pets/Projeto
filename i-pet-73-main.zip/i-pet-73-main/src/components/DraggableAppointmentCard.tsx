import React from 'react';
import { Draggable } from '@hello-pangea/dnd';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, User, Phone, Heart, Edit, Trash2, GripVertical } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Appointment } from '@/hooks/useAppointments';

interface DraggableAppointmentCardProps {
  appointment: Appointment;
  index: number;
  onStatusChange: (id: number, status: string) => void;
  onEdit: (id: number) => void;
  onDelete: (id: number) => void;
}

const DraggableAppointmentCard = ({
  appointment,
  index,
  onStatusChange,
  onEdit,
  onDelete
}: DraggableAppointmentCardProps) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmado':
        return 'bg-success text-success-foreground';
      case 'em_andamento':
        return 'bg-warning text-warning-foreground';
      case 'pendente':
        return 'bg-destructive text-destructive-foreground';
      case 'agendado':
        return 'bg-primary text-primary-foreground';
      default:
        return 'bg-secondary text-secondary-foreground';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'confirmado': return 'Confirmado';
      case 'em_andamento': return 'Em Andamento';
      case 'pendente': return 'Pendente';
      case 'agendado': return 'Agendado';
      default: return status;
    }
  };

  const getNextStatus = (currentStatus: string) => {
    switch (currentStatus) {
      case 'agendado': return 'confirmado';
      case 'confirmado': return 'em_andamento';
      case 'em_andamento': return 'confirmado';
      case 'pendente': return 'confirmado';
      default: return 'confirmado';
    }
  };

  return (
    <Draggable draggableId={appointment.id.toString()} index={index}>
      {(provided, snapshot) => (
        <Card
          ref={provided.innerRef}
          {...provided.draggableProps}
          className={cn(
            "shadow-soft transition-all duration-200 hover:shadow-md",
            snapshot.isDragging && "rotate-1 shadow-lg scale-105",
            "group relative"
          )}
        >
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div className="flex-1 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      {...provided.dragHandleProps}
                      className="opacity-0 group-hover:opacity-100 transition-opacity cursor-grab"
                    >
                      <GripVertical className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <Clock className="h-4 w-4 text-primary" />
                    <span className="font-mono font-medium text-lg">{appointment.time}</span>
                  </div>
                  <Badge 
                    className={cn("cursor-pointer", getStatusColor(appointment.status))}
                    onClick={() => onStatusChange(appointment.id, getNextStatus(appointment.status))}
                  >
                    {getStatusText(appointment.status)}
                  </Badge>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{appointment.client}</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Heart className="h-4 w-4 text-muted-foreground" />
                    <span>{appointment.pet}</span>
                    {appointment.breed && (
                      <span className="text-muted-foreground">({appointment.breed})</span>
                    )}
                  </div>
                  
                  <div className="text-sm font-medium text-primary">
                    {appointment.service}
                  </div>
                  
                  {appointment.phone && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Phone className="h-3 w-3" />
                      {appointment.phone}
                    </div>
                  )}
                  
                  {appointment.notes && (
                    <div className="text-sm text-muted-foreground bg-muted/50 p-2 rounded">
                      {appointment.notes}
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="flex gap-2 mt-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onEdit(appointment.id)}
                className="flex-1"
              >
                <Edit className="mr-1 h-3 w-3" />
                Editar
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onDelete(appointment.id)}
                className="text-destructive hover:text-destructive"
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </Draggable>
  );
};

export default DraggableAppointmentCard;
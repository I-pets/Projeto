import { Bell, Mail, MessageSquare, Smartphone } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ReminderSettingsProps {
  value?: {
    sms: boolean;
    email: boolean;
    whatsapp: boolean;
    timeBefore: number;
  };
  onChange: (value: {
    sms: boolean;
    email: boolean;
    whatsapp: boolean;
    timeBefore: number;
  }) => void;
}

const ReminderSettings = ({ value, onChange }: ReminderSettingsProps) => {
  const defaultValue = {
    sms: false,
    email: false,
    whatsapp: false,
    timeBefore: 60
  };

  const currentValue = value || defaultValue;

  const handleChange = (field: keyof typeof currentValue, newValue: boolean | number) => {
    onChange({
      ...currentValue,
      [field]: newValue
    });
  };

  const timeOptions = [
    { value: 15, label: "15 minutos antes" },
    { value: 30, label: "30 minutos antes" },
    { value: 60, label: "1 hora antes" },
    { value: 120, label: "2 horas antes" },
    { value: 1440, label: "1 dia antes" }
  ];

  return (
    <Card className="shadow-soft">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Configurações de Lembretes
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Smartphone className="h-5 w-5 text-muted-foreground" />
              <Label htmlFor="sms-reminder">SMS</Label>
            </div>
            <Switch
              id="sms-reminder"
              checked={currentValue.sms}
              onCheckedChange={(checked) => handleChange('sms', checked)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Mail className="h-5 w-5 text-muted-foreground" />
              <Label htmlFor="email-reminder">Email</Label>
            </div>
            <Switch
              id="email-reminder"
              checked={currentValue.email}
              onCheckedChange={(checked) => handleChange('email', checked)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-muted-foreground" />
              <Label htmlFor="whatsapp-reminder">WhatsApp</Label>
            </div>
            <Switch
              id="whatsapp-reminder"
              checked={currentValue.whatsapp}
              onCheckedChange={(checked) => handleChange('whatsapp', checked)}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Enviar lembrete</Label>
          <Select 
            value={currentValue.timeBefore.toString()} 
            onValueChange={(value) => handleChange('timeBefore', parseInt(value))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {timeOptions.map((option) => (
                <SelectItem key={option.value} value={option.value.toString()}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {(currentValue.sms || currentValue.email || currentValue.whatsapp) && (
          <div className="p-3 bg-primary/10 rounded-lg">
            <p className="text-sm text-primary">
              ✓ Lembretes serão enviados automaticamente para os clientes
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ReminderSettings;
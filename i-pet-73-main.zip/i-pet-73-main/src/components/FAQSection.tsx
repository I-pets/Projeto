
import { useState } from 'react';
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from '@/components/ui/accordion';
import { ChatBox } from './ChatBox';

const faqs = [
  {
    question: "Como funciona o teste grátis de 14 dias?",
    answer: "Você pode usar todas as funcionalidades do I-Pet por 14 dias sem nenhum custo. Não é necessário cartão de crédito para começar. Após o período, você pode escolher um plano que melhor se adequa ao seu negócio."
  },
  {
    question: "Posso migrar meus dados de outro sistema?",
    answer: "Sim! Nossa equipe de suporte ajuda na migração dos seus dados de clientes, pets e histórico de serviços. O processo é simples e não há perda de informações importantes."
  },
  {
    question: "O sistema funciona offline?",
    answer: "O I-Pet é um sistema baseado na nuvem, então precisa de conexão com internet. Porém, garantimos 99.9% de uptime e acesso rápido de qualquer dispositivo."
  },
  {
    question: "Como funciona a integração com WhatsApp?",
    answer: "O sistema envia lembretes automáticos via WhatsApp para seus clientes, confirmações de agendamento e notificações importantes. A integração é nativa e muito fácil de configurar."
  },
  {
    question: "Quantos usuários podem acessar o sistema?",
    answer: "Depende do plano escolhido. O plano básico permite até 3 usuários simultâneos, e os planos superiores oferecem usuários ilimitados para sua equipe."
  },
  {
    question: "Os dados são seguros?",
    answer: "Sim! Utilizamos criptografia avançada, backup automático na nuvem e estamos em conformidade com a LGPD. Seus dados e de seus clientes estão completamente protegidos."
  },
  {
    question: "Posso cancelar a qualquer momento?",
    answer: "Claro! Não há fidelidade. Você pode cancelar sua assinatura a qualquer momento através das configurações da conta ou entrando em contato conosco."
  },
  {
    question: "Como funciona o suporte técnico?",
    answer: "Oferecemos suporte via chat, WhatsApp e email durante horário comercial. Também temos uma base de conhecimento completa e tutoriais em vídeo para ajudar você."
  }
];

export function FAQSection() {
  return (
    <section id="faq" className="py-20 px-4 bg-muted/30">
      <div className="container mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Perguntas Frequentes
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Tire suas dúvidas sobre o I-Pet e descubra como podemos ajudar seu pet shop
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* FAQ Accordion */}
          <div className="animate-fade-in">
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem 
                  key={index} 
                  value={`item-${index}`}
                  className="border border-border/50 rounded-lg px-6 bg-background"
                >
                  <AccordionTrigger className="text-left hover:no-underline">
                    <span className="text-foreground font-medium">{faq.question}</span>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>

          {/* Chat Box */}
          <div className="animate-fade-in lg:sticky lg:top-8">
            <ChatBox />
          </div>
        </div>
      </div>
    </section>
  );
}

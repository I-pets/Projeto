import { useState } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, CheckCircle } from "lucide-react";
import { format, addDays, isWeekend, isSameDay } from "date-fns";
import { ptBR } from "date-fns/locale";

interface TimeSlot {
  time: string;
  available: boolean;
}

interface AppointmentCalendarProps {
  selectedDate: Date | undefined;
  selectedTime: string;
  onDateSelect: (date: Date | undefined) => void;
  onTimeSelect: (time: string) => void;
  existingAppointments?: Array<{ date: string; time: string }>;
}

const AppointmentCalendar = ({
  selectedDate,
  selectedTime,
  onDateSelect,
  onTimeSelect,
  existingAppointments = []
}: AppointmentCalendarProps) => {
  const timeSlots: TimeSlot[] = [
    { time: "08:00", available: true },
    { time: "09:00", available: true },
    { time: "10:00", available: true },
    { time: "11:00", available: true },
    { time: "14:00", available: true },
    { time: "15:00", available: true },
    { time: "16:00", available: true },
    { time: "17:00", available: true },
  ];

  const isTimeSlotAvailable = (time: string) => {
    if (!selectedDate) return false;
    
    const dateStr = format(selectedDate, "yyyy-MM-dd");
    return !existingAppointments.some(
      appointment => appointment.date === dateStr && appointment.time === time
    );
  };

  const getAvailableSlots = () => {
    if (!selectedDate) return [];
    
    return timeSlots.filter(slot => isTimeSlotAvailable(slot.time));
  };

  const isDateDisabled = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Desabilita datas passadas e finais de semana
    return date < today || isWeekend(date);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Calendário */}
      <Card>
        <CardHeader>
          <CardTitle>Selecione a Data</CardTitle>
          <CardDescription>
            Escolha uma data disponível para o agendamento
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={onDateSelect}
            disabled={isDateDisabled}
            className="rounded-md border pointer-events-auto"
            locale={ptBR}
          />
        </CardContent>
      </Card>

      {/* Horários */}
      <Card>
        <CardHeader>
          <CardTitle>Horários Disponíveis</CardTitle>
          <CardDescription>
            {selectedDate 
              ? `${format(selectedDate, "dd 'de' MMMM", { locale: ptBR })}`
              : "Selecione uma data primeiro"
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          {selectedDate ? (
            <div className="grid grid-cols-2 gap-3">
              {getAvailableSlots().map((slot) => (
                <Button
                  key={slot.time}
                  variant={selectedTime === slot.time ? "default" : "outline"}
                  className={`justify-start ${
                    selectedTime === slot.time ? "bg-primary text-primary-foreground" : ""
                  }`}
                  onClick={() => onTimeSelect(slot.time)}
                >
                  <Clock className="h-4 w-4 mr-2" />
                  {slot.time}
                  {selectedTime === slot.time && (
                    <CheckCircle className="h-4 w-4 ml-auto" />
                  )}
                </Button>
              ))}
              {getAvailableSlots().length === 0 && (
                <div className="col-span-2 text-center py-6">
                  <p className="text-muted-foreground">
                    Nenhum horário disponível para esta data
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-8">
              <Clock className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground">
                Selecione uma data para ver os horários disponíveis
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AppointmentCalendar;
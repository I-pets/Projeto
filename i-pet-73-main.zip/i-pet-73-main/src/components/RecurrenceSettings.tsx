import { useState } from "react";
import { Calendar, Clock, Repeat } from "lucide-react";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

interface RecurrenceSettingsProps {
  value?: {
    type: 'none' | 'daily' | 'weekly' | 'monthly';
    interval: number;
    endDate?: Date;
    occurrences?: number;
  };
  onChange: (value: {
    type: 'none' | 'daily' | 'weekly' | 'monthly';
    interval: number;
    endDate?: Date;
    occurrences?: number;
  }) => void;
}

const RecurrenceSettings = ({ value, onChange }: RecurrenceSettingsProps) => {
  const [endType, setEndType] = useState<'date' | 'occurrences'>('occurrences');

  const handleTypeChange = (type: 'none' | 'daily' | 'weekly' | 'monthly') => {
    onChange({
      type,
      interval: value?.interval || 1,
      endDate: value?.endDate,
      occurrences: value?.occurrences || 5
    });
  };

  const handleIntervalChange = (interval: number) => {
    if (value) {
      onChange({
        ...value,
        interval
      });
    }
  };

  const handleEndDateChange = (date: Date | undefined) => {
    if (value) {
      onChange({
        ...value,
        endDate: date
      });
    }
  };

  const handleOccurrencesChange = (occurrences: number) => {
    if (value) {
      onChange({
        ...value,
        occurrences
      });
    }
  };

  if (!value || value.type === 'none') {
    return (
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Repeat className="h-5 w-5" />
            Recorrência
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Select value="none" onValueChange={handleTypeChange}>
            <SelectTrigger>
              <SelectValue placeholder="Tipo de recorrência" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">Sem recorrência</SelectItem>
              <SelectItem value="daily">Diária</SelectItem>
              <SelectItem value="weekly">Semanal</SelectItem>
              <SelectItem value="monthly">Mensal</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-soft">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Repeat className="h-5 w-5" />
          Configurações de Recorrência
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Tipo de Recorrência</Label>
          <Select value={value.type} onValueChange={handleTypeChange}>
            <SelectTrigger>
              <SelectValue placeholder="Tipo de recorrência" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">Sem recorrência</SelectItem>
              <SelectItem value="daily">Diária</SelectItem>
              <SelectItem value="weekly">Semanal</SelectItem>
              <SelectItem value="monthly">Mensal</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>
            Repetir a cada {value.type === 'daily' ? 'dia(s)' : 
                           value.type === 'weekly' ? 'semana(s)' : 
                           'mês(es)'}
          </Label>
          <Input
            type="number"
            min="1"
            value={value.interval}
            onChange={(e) => handleIntervalChange(Number(e.target.value))}
            className="w-20"
          />
        </div>

        <div className="space-y-4">
          <Label>Terminar:</Label>
          <div className="flex gap-2">
            <Button
              variant={endType === 'occurrences' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setEndType('occurrences')}
            >
              Após X vezes
            </Button>
            <Button
              variant={endType === 'date' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setEndType('date')}
            >
              Em uma data
            </Button>
          </div>

          {endType === 'occurrences' && (
            <div className="space-y-2">
              <Label>Número de ocorrências</Label>
              <Input
                type="number"
                min="1"
                value={value.occurrences || 5}
                onChange={(e) => handleOccurrencesChange(Number(e.target.value))}
                className="w-20"
              />
            </div>
          )}

          {endType === 'date' && (
            <div className="space-y-2">
              <Label>Data final</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !value.endDate && "text-muted-foreground"
                    )}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {value.endDate ? format(value.endDate, "dd/MM/yyyy") : "Selecionar data"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={value.endDate}
                    onSelect={handleEndDateChange}
                    initialFocus
                    className="p-3 pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default RecurrenceSettings;
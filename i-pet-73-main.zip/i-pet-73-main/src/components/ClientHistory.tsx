import { useState } from "react";
import { History, User, Calendar, DollarSign, TrendingUp, Heart } from "lucide-react";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAppointments } from "@/hooks/useAppointments";

const ClientHistory = () => {
  const { getAllClients, getClientHistory } = useAppointments();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedClient, setSelectedClient] = useState<string | null>(null);

  const allClients = getAllClients();
  const filteredClients = allClients.filter(client =>
    client.clientName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const clientHistoryData = selectedClient ? getClientHistory(selectedClient) : null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmado': return 'bg-success';
      case 'em_andamento': return 'bg-warning';
      case 'pendente': return 'bg-destructive';
      case 'agendado': return 'bg-primary';
      default: return 'bg-muted';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'confirmado': return 'Confirmado';
      case 'em_andamento': return 'Em Andamento';
      case 'pendente': return 'Pendente';
      case 'agendado': return 'Agendado';
      default: return status;
    }
  };

  return (
    <Card className="shadow-soft">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <History className="h-5 w-5" />
          Histórico de Clientes
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input
            placeholder="Buscar cliente..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-md"
          />

          <Tabs defaultValue="list" className="w-full">
            <TabsList>
              <TabsTrigger value="list">Lista de Clientes</TabsTrigger>
              {selectedClient && (
                <TabsTrigger value="history">Histórico de {selectedClient}</TabsTrigger>
              )}
            </TabsList>
            
            <TabsContent value="list" className="space-y-4">
              {filteredClients.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <User className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Nenhum cliente encontrado</p>
                </div>
              ) : (
                <div className="grid gap-4">
                  {filteredClients.map((client) => (
                    <Card key={client.clientName} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                         <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                           <div className="flex-1">
                             <div className="flex items-center gap-2 mb-2">
                               <User className="h-4 w-4 text-muted-foreground" />
                               <span className="font-medium">{client.clientName}</span>
                             </div>
                             <div className="text-sm text-muted-foreground space-y-1">
                               <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                                 <p>Total de visitas: {client.totalVisits}</p>
                                 <p>Última visita: {format(client.lastVisit, "dd/MM/yyyy")}</p>
                                 <p className="sm:col-span-1 lg:col-span-1">Valor total: R$ {client.totalSpent.toFixed(2)}</p>
                               </div>
                               <div className="flex items-start gap-1 flex-wrap mt-2">
                                 <span className="text-xs font-medium">Serviços preferidos:</span>
                                 <div className="flex flex-wrap gap-1">
                                   {client.preferredServices.map((service, index) => (
                                     <Badge key={index} variant="secondary" className="text-xs">
                                       {service}
                                     </Badge>
                                   ))}
                                 </div>
                               </div>
                             </div>
                           </div>
                           <Button
                             variant="outline"
                             size="sm"
                             onClick={() => setSelectedClient(client.clientName)}
                             className="shrink-0"
                           >
                             Ver Histórico
                           </Button>
                         </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {selectedClient && clientHistoryData && (
              <TabsContent value="history" className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold mb-2 sm:mb-0">Histórico de {selectedClient}</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedClient(null)}
                  >
                    Voltar
                  </Button>
                </div>

                {/* Resumo do Cliente */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="p-3 sm:p-4 text-center">
                      <Calendar className="h-6 w-6 sm:h-8 sm:w-8 mx-auto mb-2 text-primary" />
                      <div className="text-xl sm:text-2xl font-bold">{clientHistoryData.totalVisits}</div>
                      <p className="text-xs sm:text-sm text-muted-foreground">Visitas</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-3 sm:p-4 text-center">
                      <DollarSign className="h-6 w-6 sm:h-8 sm:w-8 mx-auto mb-2 text-success" />                      
                      <div className="text-lg sm:text-2xl font-bold">R$ {clientHistoryData.totalSpent.toFixed(2)}</div>
                      <p className="text-xs sm:text-sm text-muted-foreground">Total Gasto</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-3 sm:p-4 text-center">
                      <TrendingUp className="h-6 w-6 sm:h-8 sm:w-8 mx-auto mb-2 text-warning" />
                      <div className="text-xl sm:text-2xl font-bold">
                        {clientHistoryData.preferredServices.length}
                      </div>
                      <p className="text-xs sm:text-sm text-muted-foreground">Serviços Únicos</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-3 sm:p-4 text-center">
                      <Heart className="h-6 w-6 sm:h-8 sm:w-8 mx-auto mb-2 text-destructive" />
                      <div className="text-xl sm:text-2xl font-bold">
                        {format(clientHistoryData.lastVisit, "dd/MM")}
                      </div>
                      <p className="text-xs sm:text-sm text-muted-foreground">Última Visita</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Histórico de Agendamentos */}
                <Card>
                  <CardHeader>
                    <CardTitle>Agendamentos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {clientHistoryData.appointments.map((appointment) => (
                        <div
                          key={appointment.id}
                          className="flex flex-col sm:flex-row sm:items-center justify-between p-3 border rounded-lg gap-3 sm:gap-0"
                        >
                          <div className="flex-1">
                            <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-1">
                              <span className="font-medium">{appointment.pet}</span>
                              <Badge className={getStatusColor(appointment.status)}>
                                {getStatusText(appointment.status)}
                              </Badge>
                            </div>
                            <div className="text-sm text-muted-foreground space-y-1">
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1">
                                <p>Serviço: {appointment.service}</p>
                                <p>Data: {format(appointment.date, "dd/MM/yyyy")} às {appointment.time}</p>
                              </div>
                              {appointment.notes && (
                                <p className="italic text-xs">Obs: {appointment.notes}</p>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            )}
          </Tabs>
        </div>
      </CardContent>
    </Card>
  );
};

export default ClientHistory;
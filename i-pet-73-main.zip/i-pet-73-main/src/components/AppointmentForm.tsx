import { useState } from "react";
import { Calendar, X } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import RecurrenceSettings from "./RecurrenceSettings";
import ReminderSettings from "./ReminderSettings";
import { type AppointmentFormData } from "@/hooks/useAppointments";


interface AppointmentFormProps {
  formData: AppointmentFormData;
  setFormData: (data: AppointmentFormData) => void;
  onSubmit: () => void;
  onCancel: () => void;
  isEdit?: boolean;
  availableSlots: string[];
}

const clientesComPets = [
  { nome: "Maria Silva", pets: ["Rex", "Mimi"] },
  { nome: "João Santos", pets: ["Thor"] },
  { nome: "Ana Costa", pets: ["Luna", "Buddy", "Mel"] },
  { nome: "Carlos Lima", pets: ["Bolt"] },
  { nome: "Paula Rocha", pets: ["Coco", "Nala"] }
];

const servicosPorCategoria = {
  consultas: {
    nome: "🏥 Consultas e Exames",
    servicos: ["Consulta Veterinária", "Consulta + Exames", "Exames"]
  },
  estetica: {
    nome: "🛁 Estética e Higiene", 
    servicos: ["Banho e Tosa", "Tosa", "Banho"]
  },
  procedimentos: {
    nome: "💉 Procedimentos Médicos",
    servicos: ["Vacinação", "Cirurgia", "Castração"]
  }
};

const funcionarios = [
  "Dr. João",
  "Dr. Maria", 
  "Ana",
  "Carlos",
  "Paula"
];

const AppointmentForm = ({ 
  formData, 
  setFormData, 
  onSubmit, 
  onCancel, 
  isEdit = false,
  availableSlots 
}: AppointmentFormProps) => {
  return (
    <Tabs defaultValue="basic" className="w-full">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="basic">Básico</TabsTrigger>
        <TabsTrigger value="recurrence">Recorrência</TabsTrigger>
        <TabsTrigger value="reminders">Lembretes</TabsTrigger>
      </TabsList>
      
      <TabsContent value="basic" className="space-y-6 mt-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="client">Cliente *</Label>
          <Select 
            value={formData.client} 
            onValueChange={(value) => setFormData({...formData, client: value, pet: ""})}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selecione o cliente" />
            </SelectTrigger>
            <SelectContent>
              {clientesComPets.map((cliente, index) => (
                <SelectItem key={index} value={cliente.nome}>{cliente.nome}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="pet">Pet *</Label>
          <Select 
            value={formData.pet} 
            onValueChange={(value) => setFormData({...formData, pet: value})}
            disabled={!formData.client}
          >
            <SelectTrigger>
              <SelectValue placeholder={formData.client ? "Selecione o pet" : "Primeiro selecione o cliente"} />
            </SelectTrigger>
            <SelectContent>
              {formData.client && clientesComPets
                .find(c => c.nome === formData.client)
                ?.pets.map((pet, index) => (
                  <SelectItem key={index} value={pet}>{pet}</SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="breed">Raça</Label>
          <Input
            value={formData.breed}
            onChange={(e) => setFormData({...formData, breed: e.target.value})}
            placeholder="Ex: Golden Retriever, SRD..."
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="phone">Telefone</Label>
          <Input
            value={formData.phone}
            onChange={(e) => setFormData({...formData, phone: e.target.value})}
            placeholder="(11) 99999-9999"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="serviceCategory">Categoria *</Label>
          <Select 
            value={formData.serviceCategory} 
            onValueChange={(value) => setFormData({
              ...formData, 
              serviceCategory: value as 'consultas' | 'estetica' | 'procedimentos',
              service: "" // Reset service when category changes
            })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selecione a categoria" />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(servicosPorCategoria).map(([key, categoria]) => (
                <SelectItem key={key} value={key}>{categoria.nome}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="service">Serviço *</Label>
          <Select 
            value={formData.service} 
            onValueChange={(value) => setFormData({...formData, service: value})}
            disabled={!formData.serviceCategory}
          >
            <SelectTrigger>
              <SelectValue placeholder={formData.serviceCategory ? "Selecione o serviço" : "Primeiro selecione a categoria"} />
            </SelectTrigger>
            <SelectContent>
              {formData.serviceCategory && servicosPorCategoria[formData.serviceCategory].servicos.map((servico, index) => (
                <SelectItem key={index} value={servico}>{servico}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="staff">Funcionário *</Label>
          <Select 
            value={formData.staff} 
            onValueChange={(value) => setFormData({...formData, staff: value})}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selecione o funcionário" />
            </SelectTrigger>
            <SelectContent>
              {funcionarios.map((funcionario, index) => (
                <SelectItem key={index} value={funcionario}>{funcionario}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="time">Horário *</Label>
          <Select 
            value={formData.time} 
            onValueChange={(value) => setFormData({...formData, time: value})}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selecione o horário" />
            </SelectTrigger>
            <SelectContent>
              {availableSlots.map((horario, index) => (
                <SelectItem key={index} value={horario}>{horario}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="date">Data do Agendamento *</Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                "w-full justify-start text-left font-normal",
                !formData.date && "text-muted-foreground"
              )}
            >
              <Calendar className="mr-2 h-4 w-4" />
              {formData.date ? format(formData.date, "dd/MM/yyyy") : <span>Selecione uma data</span>}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <CalendarComponent
              mode="single"
              selected={formData.date}
              onSelect={(date) => date && setFormData({...formData, date})}
              disabled={(date) => date < new Date()}
              initialFocus
              className={cn("p-3 pointer-events-auto")}
            />
          </PopoverContent>
        </Popover>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="notes">Observações</Label>
        <Textarea
          value={formData.notes}
          onChange={(e) => setFormData({...formData, notes: e.target.value})}
          placeholder="Observações adicionais sobre o agendamento..."
          rows={3}
        />
      </div>
      
      </TabsContent>
      
      <TabsContent value="recurrence" className="space-y-6 mt-4">
        <RecurrenceSettings
          value={formData.recurrence}
          onChange={(recurrence) => setFormData({...formData, recurrence})}
        />
      </TabsContent>
      
      <TabsContent value="reminders" className="space-y-6 mt-4">
        <ReminderSettings
          value={formData.reminders}
          onChange={(reminders) => setFormData({...formData, reminders})}
        />
      </TabsContent>
      
      <div className="flex gap-3 pt-4">
        <Button
          variant="outline"
          className="flex-1"
          onClick={onCancel}
        >
          Cancelar
        </Button>
        <Button
          className="flex-1 bg-gradient-primary hover:opacity-90"
          onClick={onSubmit}
        >
          {isEdit ? "Salvar Alterações" : "Criar Agendamento"}
        </Button>
      </div>
    </Tabs>
  );
};

export default AppointmentForm;
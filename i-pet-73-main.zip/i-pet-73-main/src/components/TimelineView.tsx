import React from 'react';
import { format } from 'date-fns';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, Plus, User, Phone } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Appointment } from '@/hooks/useAppointments';

interface TimelineViewProps {
  appointments: Appointment[];
  selectedDate: Date;
  availableSlots: string[];
  onSlotClick?: (time: string) => void;
  onAppointmentClick?: (appointment: Appointment) => void;
}

const TimelineView = ({ 
  appointments, 
  selectedDate, 
  availableSlots, 
  onSlotClick, 
  onAppointmentClick 
}: TimelineViewProps) => {
  // Todos os horários do dia (8:00 às 18:00, de 30 em 30 minutos)
  const allTimeSlots = [
    "08:00", "08:30", "09:00", "09:30", "10:00", "10:30",
    "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
    "14:00", "14:30", "15:00", "15:30", "16:00", "16:30",
    "17:00", "17:30", "18:00"
  ];

  // Filtra agendamentos do dia selecionado
  const dayAppointments = appointments.filter(appointment => 
    format(appointment.date, 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd')
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmado':
        return 'bg-success/10 border-success text-success';
      case 'em_andamento':
        return 'bg-warning/10 border-warning text-warning';
      case 'pendente':
        return 'bg-destructive/10 border-destructive text-destructive';
      case 'agendado':
        return 'bg-primary/10 border-primary text-primary';
      default:
        return 'bg-muted border-border text-muted-foreground';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'confirmado': return 'Confirmado';
      case 'em_andamento': return 'Em Andamento';
      case 'pendente': return 'Pendente';
      case 'agendado': return 'Agendado';
      default: return status;
    }
  };

  return (
    <Card className="shadow-soft">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5 text-primary" />
          Timeline - {format(selectedDate, 'dd/MM/yyyy')}
          <Badge variant="outline" className="ml-2">
            {dayAppointments.length} agendamentos
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {allTimeSlots.map((timeSlot) => {
            const appointment = dayAppointments.find(app => app.time === timeSlot);
            const isAvailable = availableSlots.includes(timeSlot);

            return (
              <div
                key={timeSlot}
                className={cn(
                  "flex items-center justify-between p-3 rounded-lg border transition-colors",
                  appointment 
                    ? getStatusColor(appointment.status)
                    : isAvailable 
                      ? "border-dashed border-muted-foreground/20 hover:border-primary/50 hover:bg-primary/5 cursor-pointer"
                      : "bg-muted/20 border-muted"
                )}
                onClick={() => {
                  if (appointment && onAppointmentClick) {
                    onAppointmentClick(appointment);
                  } else if (isAvailable && onSlotClick) {
                    onSlotClick(timeSlot);
                  }
                }}
              >
                <div className="flex items-center gap-3">
                  <div className="text-sm font-mono font-medium w-12">
                    {timeSlot}
                  </div>
                  
                  {appointment ? (
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <User className="h-4 w-4" />
                        <span className="font-medium">{appointment.client}</span>
                        <span className="text-sm text-muted-foreground">
                          ({appointment.pet})
                        </span>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {appointment.service}
                      </div>
                      {appointment.phone && (
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                          <Phone className="h-3 w-3" />
                          {appointment.phone}
                        </div>
                      )}
                    </div>
                  ) : isAvailable ? (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Plus className="h-4 w-4" />
                      <span className="text-sm">Horário disponível</span>
                    </div>
                  ) : (
                    <div className="text-sm text-muted-foreground">
                      Horário não disponível
                    </div>
                  )}
                </div>

                {appointment && (
                  <Badge variant="outline" className={cn("text-xs", getStatusColor(appointment.status))}>
                    {getStatusText(appointment.status)}
                  </Badge>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default TimelineView;
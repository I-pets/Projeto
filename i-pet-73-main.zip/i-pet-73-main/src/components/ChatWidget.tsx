
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { MessageCircle, X, Phone, HelpCircle } from 'lucide-react';

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);

  const handleWhatsApp = () => {
    const message = encodeURIComponent(
      `Olá! Estou no site do I-Pet e gostaria de mais informações sobre o sistema.`
    );
    window.open(`https://wa.me/5511999999999?text=${message}`, '_blank');
    setIsOpen(false);
  };

  const scrollToFAQ = () => {
    const faqSection = document.getElementById('faq');
    if (faqSection) {
      faqSection.scrollIntoView({ behavior: 'smooth' });
      setIsOpen(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Chat Options Card */}
      {isOpen && (
        <Card className="mb-4 w-72 shadow-strong animate-scale-in">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-foreground">Como podemos ajudar?</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="space-y-3">
              <Button
                variant="outline"
                className="w-full justify-start border-green-500 text-green-600 hover:bg-green-50"
                onClick={handleWhatsApp}
              >
                <Phone className="mr-2 h-4 w-4" />
                Falar no WhatsApp
              </Button>
              
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={scrollToFAQ}
              >
                <HelpCircle className="mr-2 h-4 w-4" />
                Ver Perguntas Frequentes
              </Button>
            </div>
            
            <div className="mt-4 text-xs text-muted-foreground text-center">
              Respondemos em poucos minutos! 🚀
            </div>
          </CardContent>
        </Card>
      )}

      {/* Floating Button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        size="lg"
        className="rounded-full w-14 h-14 shadow-strong bg-gradient-primary hover:scale-110 transition-transform"
      >
        {isOpen ? (
          <X className="h-6 w-6" />
        ) : (
          <MessageCircle className="h-6 w-6" />
        )}
      </Button>
    </div>
  );
}

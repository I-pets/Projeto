import { Trash2, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface Pet {
  nome: string;
  especie: string;
  raca: string;
  idade: string;
  peso: string;
  cor: string;
  observacoesMedicas: string;
}

interface PetFormProps {
  pets: Pet[];
  onChange: (pets: Pet[]) => void;
}

export function PetForm({ pets, onChange }: PetFormProps) {
  const especies = ["Cão", "Gato", "Pássaro", "Hamster", "Coelho", "Outro"];

  const updatePet = (index: number, field: keyof Pet, value: string) => {
    const updatedPets = pets.map((pet, i) => 
      i === index ? { ...pet, [field]: value } : pet
    );
    onChange(updatedPets);
  };

  const addPet = () => {
    onChange([...pets, { nome: "", especie: "", raca: "", idade: "", peso: "", cor: "", observacoesMedicas: "" }]);
  };

  const removePet = (index: number) => {
    if (pets.length > 1) {
      onChange(pets.filter((_, i) => i !== index));
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label className="text-lg font-semibold">Pets do Cliente</Label>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={addPet}
          className="text-primary border-primary/30 hover:bg-primary/10"
        >
          <Plus className="h-4 w-4 mr-2" />
          Adicionar Pet
        </Button>
      </div>
      
      {pets.map((pet, index) => (
        <Card key={index} className="border-border/50">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">
                Pet {index + 1}
                {pet.nome && ` - ${pet.nome}`}
              </CardTitle>
              {pets.length > 1 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => removePet(index)}
                  className="text-destructive hover:text-destructive hover:bg-destructive/10"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Nome do Pet *</Label>
                <Input
                  value={pet.nome}
                  onChange={(e) => updatePet(index, "nome", e.target.value)}
                  placeholder="Ex: Rex, Mimi..."
                />
              </div>
              
              <div className="space-y-2">
                <Label>Espécie *</Label>
                <Select 
                  value={pet.especie} 
                  onValueChange={(value) => updatePet(index, "especie", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a espécie" />
                  </SelectTrigger>
                  <SelectContent>
                    {especies.map((especie) => (
                      <SelectItem key={especie} value={especie}>{especie}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Raça</Label>
                <Input
                  value={pet.raca}
                  onChange={(e) => updatePet(index, "raca", e.target.value)}
                  placeholder="Ex: Golden Retriever, SRD..."
                />
              </div>
              
              <div className="space-y-2">
                <Label>Idade</Label>
                <Input
                  value={pet.idade}
                  onChange={(e) => updatePet(index, "idade", e.target.value)}
                  placeholder="Ex: 2 anos, 6 meses..."
                />
              </div>
              
              <div className="space-y-2">
                <Label>Peso</Label>
                <Input
                  value={pet.peso}
                  onChange={(e) => updatePet(index, "peso", e.target.value)}
                  placeholder="Ex: 15kg, 3.5kg..."
                />
              </div>
              
              <div className="space-y-2">
                <Label>Cor</Label>
                <Input
                  value={pet.cor}
                  onChange={(e) => updatePet(index, "cor", e.target.value)}
                  placeholder="Ex: Dourado, Preto..."
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label>Observações Médicas</Label>
              <Textarea
                value={pet.observacoesMedicas}
                onChange={(e) => updatePet(index, "observacoesMedicas", e.target.value)}
                placeholder="Alergias, medicamentos, condições especiais..."
                rows={2}
              />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
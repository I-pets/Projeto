import { useState } from "react";
import { Clock, Plus, User, Phone, Calendar, AlertCircle, CheckCircle2, X } from "lucide-react";
import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { useAppointments, type WaitingListEntry } from "@/hooks/useAppointments";
import { cn } from "@/lib/utils";
const WaitingListManager = () => {
  const {
    waitingList,
    addToWaitingList,
    removeFromWaitingList,
    promoteFromWaitingList
  } = useAppointments();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    client: "",
    pet: "",
    phone: "",
    service: "",
    preferredDate: new Date(),
    notes: "",
    priority: "medium" as 'low' | 'medium' | 'high'
  });
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.client && formData.pet && formData.service) {
      addToWaitingList(formData);
      setFormData({
        client: "",
        pet: "",
        phone: "",
        service: "",
        preferredDate: new Date(),
        notes: "",
        priority: "medium"
      });
      setIsDialogOpen(false);
    }
  };
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-destructive';
      case 'medium':
        return 'bg-warning';
      case 'low':
        return 'bg-muted';
      default:
        return 'bg-muted';
    }
  };
  const getPriorityText = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'Alta';
      case 'medium':
        return 'Média';
      case 'low':
        return 'Baixa';
      default:
        return 'Média';
    }
  };
  const sortedWaitingList = [...waitingList].sort((a, b) => {
    const priorityOrder = {
      high: 3,
      medium: 2,
      low: 1
    };
    return priorityOrder[b.priority] - priorityOrder[a.priority];
  });
  return (
    <Card className="shadow-soft">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Lista de Espera
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Adicionar à Lista de Espera
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Adicionar Cliente à Lista de Espera</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="client">Cliente</Label>
                    <Input
                      id="client"
                      value={formData.client}
                      onChange={(e) => setFormData({...formData, client: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="pet">Pet</Label>
                    <Input
                      id="pet"
                      value={formData.pet}
                      onChange={(e) => setFormData({...formData, pet: e.target.value})}
                      required
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="phone">Telefone</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="service">Serviço</Label>
                    <Select value={formData.service} onValueChange={(value) => setFormData({...formData, service: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um serviço" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Consulta Veterinária">Consulta Veterinária</SelectItem>
                        <SelectItem value="Banho e Tosa">Banho e Tosa</SelectItem>
                        <SelectItem value="Vacinação">Vacinação</SelectItem>
                        <SelectItem value="Cirurgia">Cirurgia</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Data Preferida</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className={cn("justify-start text-left font-normal", !formData.preferredDate && "text-muted-foreground")}>
                          <Calendar className="mr-2 h-4 w-4" />
                          {formData.preferredDate ? format(formData.preferredDate, "dd/MM/yyyy") : "Selecionar data"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <CalendarComponent
                          mode="single"
                          selected={formData.preferredDate}
                          onSelect={(date) => date && setFormData({...formData, preferredDate: date})}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div>
                    <Label htmlFor="priority">Prioridade</Label>
                    <Select value={formData.priority} onValueChange={(value: 'low' | 'medium' | 'high') => setFormData({...formData, priority: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Baixa</SelectItem>
                        <SelectItem value="medium">Média</SelectItem>
                        <SelectItem value="high">Alta</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="notes">Observações</Label>
                  <Textarea
                    id="notes"
                    value={formData.notes}
                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    placeholder="Observações adicionais..."
                  />
                </div>
                <Button type="submit" className="w-full">
                  Adicionar à Lista de Espera
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          <div className="space-y-3">
            {sortedWaitingList.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Nenhum cliente na lista de espera</p>
              </div>
            ) : (
              sortedWaitingList.map((entry) => (
                <Card key={entry.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{entry.client}</span>
                          <Badge variant="outline">{entry.pet}</Badge>
                          <Badge className={getPriorityColor(entry.priority)}>
                            {getPriorityText(entry.priority)}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <p>Serviço: {entry.service}</p>
                          <p>Data preferida: {format(entry.preferredDate, "dd/MM/yyyy")}</p>
                          {entry.phone && <p>Telefone: {entry.phone}</p>}
                          {entry.notes && <p className="italic">Obs: {entry.notes}</p>}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => promoteFromWaitingList(entry.id)}
                          title="Agendar"
                        >
                          <CheckCircle2 className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeFromWaitingList(entry.id)}
                          title="Remover"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
export default WaitingListManager;
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export interface Appointment {
  id: number;
  time: string;
  client: string;
  pet: string;
  breed: string;
  service: string;
  serviceCategory: 'consultas' | 'estetica' | 'procedimentos';
  status: string;
  phone: string;
  notes: string;
  date: Date;
  staff: string;
  recurrence?: {
    type: 'none' | 'daily' | 'weekly' | 'monthly';
    interval: number;
    endDate?: Date;
    occurrences?: number;
  };
  isRecurring?: boolean;
  originalId?: number;
  reminders?: {
    sms: boolean;
    email: boolean;
    whatsapp: boolean;
    timeBefore: number; // minutes
  };
}

export interface WaitingListEntry {
  id: number;
  client: string;
  pet: string;
  phone: string;
  service: string;
  preferredDate: Date;
  notes: string;
  createdAt: Date;
  priority: 'low' | 'medium' | 'high';
}

export interface ClientHistory {
  clientName: string;
  appointments: Appointment[];
  totalVisits: number;
  totalSpent: number;
  lastVisit: Date;
  preferredServices: string[];
}

export interface AppointmentFormData {
  client: string;
  pet: string;
  breed: string;
  service: string;
  serviceCategory: 'consultas' | 'estetica' | 'procedimentos';
  date: Date;
  time: string;
  phone: string;
  notes: string;
  staff: string;
  recurrence?: {
    type: 'none' | 'daily' | 'weekly' | 'monthly';
    interval: number;
    endDate?: Date;
    occurrences?: number;
  };
  reminders?: {
    sms: boolean;
    email: boolean;
    whatsapp: boolean;
    timeBefore: number;
  };
}

const initialAppointments: Appointment[] = [
  {
    id: 1,
    time: "08:00",
    client: "Maria Silva",
    pet: "Rex",
    breed: "Golden Retriever",
    service: "Consulta Veterinária",
    serviceCategory: "consultas",
    status: "confirmado",
    phone: "(11) 99999-9999",
    notes: "Primeira consulta",
    date: new Date(),
    staff: "Dr. João"
  },
  {
    id: 2,
    time: "09:30",
    client: "João Santos",
    pet: "Mimi",
    breed: "Gato Persa",
    service: "Banho e Tosa",
    serviceCategory: "estetica",
    status: "em_andamento",
    phone: "(11) 88888-8888",
    notes: "Cliente regular",
    date: new Date(),
    staff: "Ana"
  },
  {
    id: 3,
    time: "11:00",
    client: "Ana Costa",
    pet: "Thor",
    breed: "Labrador",
    service: "Vacinação",
    serviceCategory: "procedimentos",
    status: "pendente",
    phone: "(11) 77777-7777",
    notes: "Vacina V10",
    date: new Date(),
    staff: "Dr. João"
  },
  {
    id: 4,
    time: "14:00",
    client: "Carlos Lima",
    pet: "Luna",
    breed: "SRD",
    service: "Consulta + Exames",
    serviceCategory: "consultas",
    status: "confirmado",
    phone: "(11) 66666-6666",
    notes: "Exames de rotina",
    date: new Date(),
    staff: "Dr. Maria"
  },
  {
    id: 5,
    time: "15:30",
    client: "Paula Rocha",
    pet: "Buddy",
    breed: "Shih Tzu",
    service: "Banho e Tosa",
    serviceCategory: "estetica",
    status: "agendado",
    phone: "(11) 55555-5555",
    notes: "Tosa completa",
    date: new Date(),
    staff: "Carlos"
  }
];

const allTimeSlots = [
  "08:00", "08:30", "09:00", "09:30", "10:00", "10:30",
  "11:00", "11:30", "14:00", "14:30", "15:00", "15:30",
  "16:00", "16:30", "17:00", "17:30", "18:00"
];

export const useAppointments = () => {
  const { toast } = useToast();
  const [appointments, setAppointments] = useState<Appointment[]>(initialAppointments);
  const [waitingList, setWaitingList] = useState<WaitingListEntry[]>([]);
  const [reminders, setReminders] = useState<{[key: number]: boolean}>({});

  const getStatusText = (status: string) => {
    switch (status) {
      case "confirmado": return "Confirmado";
      case "em_andamento": return "Em Andamento";
      case "pendente": return "Pendente";
      case "agendado": return "Agendado";
      default: return status;
    }
  };

  const getAvailableSlots = (selectedDate: Date, excludeId?: number) => {
    const bookedSlots = appointments
      .filter(app => 
        format(app.date, 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd') &&
        app.id !== excludeId
      )
      .map(app => app.time);
    
    return allTimeSlots.filter(slot => !bookedSlots.includes(slot));
  };

  const validateAppointment = (formData: AppointmentFormData, excludeId?: number) => {
    console.log("Validating appointment:", {
      client: formData.client,
      pet: formData.pet,
      service: formData.service,
      time: formData.time
    });
    
    if (!formData.client || !formData.pet || !formData.service || !formData.time) {
      console.log("Required fields missing");
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive"
      });
      return false;
    }

    const isSlotTaken = appointments.some(app => 
      format(app.date, 'yyyy-MM-dd') === format(formData.date, 'yyyy-MM-dd') &&
      app.time === formData.time &&
      app.id !== excludeId
    );

    if (isSlotTaken) {
      console.log("Time slot already taken");
      toast({
        title: "Horário não disponível",
        description: "Este horário já está ocupado. Por favor, escolha outro.",
        variant: "destructive"
      });
      return false;
    }

    console.log("Validation passed");
    return true;
  };

  const createRecurringAppointments = (baseAppointment: Appointment): Appointment[] => {
    const appointments: Appointment[] = [baseAppointment];
    
    if (!baseAppointment.recurrence || baseAppointment.recurrence.type === 'none') {
      return appointments;
    }

    const { type, interval, endDate, occurrences } = baseAppointment.recurrence;
    let currentDate = new Date(baseAppointment.date);
    let count = 1;
    let currentId = baseAppointment.id;

    while (count < (occurrences || 10)) {
      if (type === 'daily') {
        currentDate = new Date(currentDate.getTime() + (interval * 24 * 60 * 60 * 1000));
      } else if (type === 'weekly') {
        currentDate = new Date(currentDate.getTime() + (interval * 7 * 24 * 60 * 60 * 1000));
      } else if (type === 'monthly') {
        currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + interval, currentDate.getDate());
      }

      if (endDate && currentDate > endDate) break;

      const recurringAppointment: Appointment = {
        ...baseAppointment,
        id: currentId + count,
        date: new Date(currentDate),
        isRecurring: true,
        originalId: baseAppointment.id
      };

      appointments.push(recurringAppointment);
      count++;
    }

    return appointments;
  };

  const createAppointment = (formData: AppointmentFormData) => {
    console.log("Creating appointment with data:", formData);
    
    if (!validateAppointment(formData)) {
      console.log("Validation failed");
      return false;
    }

    const newAppointment: Appointment = {
      id: Math.max(...appointments.map(a => a.id), 0) + 1,
      time: formData.time,
      client: formData.client,
      pet: formData.pet,
      breed: formData.breed,
      service: formData.service,
      serviceCategory: formData.serviceCategory,
      status: "agendado",
      phone: formData.phone,
      notes: formData.notes,
      date: formData.date,
      staff: formData.staff,
      recurrence: formData.recurrence,
      reminders: formData.reminders
    };

    // Create recurring appointments if specified
    if (formData.recurrence && formData.recurrence.type !== 'none') {
      const recurringAppointments = createRecurringAppointments(newAppointment);
      setAppointments(prev => [...prev, ...recurringAppointments]);
    } else {
      setAppointments(prev => [...prev, newAppointment]);
    }

    console.log("New appointment created:", newAppointment);
    
    toast({
      title: "Agendamento Criado",
      description: `Agendamento para ${formData.client} criado com sucesso!`,
    });
    
    return true;
  };

  const updateAppointment = (id: number, formData: AppointmentFormData) => {
    if (!validateAppointment(formData, id)) return false;

    setAppointments(prev => prev.map(appointment => 
      appointment.id === id 
        ? { ...appointment, ...formData }
        : appointment
    ));

    toast({
      title: "Agendamento Atualizado",
      description: `Agendamento de ${formData.client} atualizado com sucesso!`,
    });

    return true;
  };

  const deleteAppointment = (id: number) => {
    const appointment = appointments.find(app => app.id === id);
    setAppointments(prev => prev.filter(app => app.id !== id));
    
    toast({
      title: "Agendamento Removido",
      description: `Agendamento de ${appointment?.client} foi removido com sucesso.`,
    });
  };

  const changeStatus = (id: number, newStatus: string) => {
    setAppointments(prev => prev.map(appointment => 
      appointment.id === id 
        ? { ...appointment, status: newStatus }
        : appointment
    ));

    toast({
      title: "Status Atualizado",
      description: `Status do agendamento alterado para ${getStatusText(newStatus)}`,
    });
  };

  const getAppointmentById = (id: number) => {
    return appointments.find(app => app.id === id);
  };

  const getStats = () => {
    const today = format(new Date(), 'yyyy-MM-dd');
    const todayAppointments = appointments.filter(app => 
      format(app.date, 'yyyy-MM-dd') === today
    );

    return {
      total: todayAppointments.length,
      confirmados: todayAppointments.filter(app => app.status === "confirmado").length,
      em_andamento: todayAppointments.filter(app => app.status === "em_andamento").length,
      pendentes: todayAppointments.filter(app => app.status === "pendente").length,
      agendados: todayAppointments.filter(app => app.status === "agendado").length
    };
  };

  const reorderAppointments = (reorderedAppointments: Appointment[]) => {
    setAppointments(reorderedAppointments);
  };

  // Waiting List Functions
  const addToWaitingList = (entry: Omit<WaitingListEntry, 'id' | 'createdAt'>) => {
    const newEntry: WaitingListEntry = {
      ...entry,
      id: Math.max(...waitingList.map(w => w.id), 0) + 1,
      createdAt: new Date()
    };
    
    setWaitingList(prev => [...prev, newEntry]);
    
    toast({
      title: "Adicionado à Lista de Espera",
      description: `${entry.client} foi adicionado à lista de espera.`,
    });
  };

  const removeFromWaitingList = (id: number) => {
    const entry = waitingList.find(w => w.id === id);
    setWaitingList(prev => prev.filter(w => w.id !== id));
    
    toast({
      title: "Removido da Lista de Espera",
      description: `${entry?.client} foi removido da lista de espera.`,
    });
  };

  const promoteFromWaitingList = (id: number) => {
    const entry = waitingList.find(w => w.id === id);
    if (entry) {
      const formData: AppointmentFormData = {
        client: entry.client,
        pet: entry.pet,
        breed: "",
        service: entry.service,
        serviceCategory: "consultas",
        date: entry.preferredDate,
        time: "",
        phone: entry.phone,
        notes: entry.notes,
        staff: ""
      };
      
      // Try to find available slot
      const availableSlots = getAvailableSlots(entry.preferredDate);
      if (availableSlots.length > 0) {
        formData.time = availableSlots[0];
        if (createAppointment(formData)) {
          removeFromWaitingList(id);
        }
      }
    }
  };

  // Reminder Functions
  const scheduleReminder = (appointmentId: number) => {
    const appointment = appointments.find(a => a.id === appointmentId);
    if (appointment?.reminders) {
      // Simulate reminder scheduling
      setReminders(prev => ({ ...prev, [appointmentId]: true }));
      
      toast({
        title: "Lembrete Agendado",
        description: `Lembrete configurado para ${appointment.client}`,
      });
    }
  };

  const cancelReminder = (appointmentId: number) => {
    setReminders(prev => ({ ...prev, [appointmentId]: false }));
    
    toast({
      title: "Lembrete Cancelado",
      description: "Lembrete foi cancelado com sucesso",
    });
  };

  // History Functions
  const getClientHistory = (clientName: string): ClientHistory => {
    const clientAppointments = appointments.filter(
      app => app.client.toLowerCase() === clientName.toLowerCase()
    );
    
    const serviceCounts = clientAppointments.reduce((acc, app) => {
      acc[app.service] = (acc[app.service] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const preferredServices = Object.entries(serviceCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3)
      .map(([service]) => service);
    
    return {
      clientName,
      appointments: clientAppointments.sort((a, b) => b.date.getTime() - a.date.getTime()),
      totalVisits: clientAppointments.length,
      totalSpent: clientAppointments.length * 50, // Mock calculation
      lastVisit: clientAppointments.length > 0 ? clientAppointments[0].date : new Date(),
      preferredServices
    };
  };

  const getAllClients = () => {
    const uniqueClients = [...new Set(appointments.map(app => app.client))];
    return uniqueClients.map(client => getClientHistory(client));
  };

  // Advanced Reports
  const getAdvancedStats = () => {
    const now = new Date();
    const today = format(now, 'yyyy-MM-dd');
    const thisMonth = format(now, 'yyyy-MM');
    
    const todayAppointments = appointments.filter(app => 
      format(app.date, 'yyyy-MM-dd') === today
    );
    
    const monthAppointments = appointments.filter(app => 
      format(app.date, 'yyyy-MM') === thisMonth
    );
    
    const serviceStats = appointments.reduce((acc, app) => {
      acc[app.service] = (acc[app.service] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    const statusStats = appointments.reduce((acc, app) => {
      acc[app.status] = (acc[app.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    return {
      today: {
        total: todayAppointments.length,
        confirmados: todayAppointments.filter(app => app.status === "confirmado").length,
        em_andamento: todayAppointments.filter(app => app.status === "em_andamento").length,
        pendentes: todayAppointments.filter(app => app.status === "pendente").length,
        agendados: todayAppointments.filter(app => app.status === "agendado").length
      },
      month: {
        total: monthAppointments.length,
        revenue: monthAppointments.length * 50, // Mock calculation
        averagePerDay: monthAppointments.length / new Date().getDate()
      },
      services: serviceStats,
      status: statusStats,
      waitingList: {
        total: waitingList.length,
        high: waitingList.filter(w => w.priority === 'high').length,
        medium: waitingList.filter(w => w.priority === 'medium').length,
        low: waitingList.filter(w => w.priority === 'low').length
      },
      recurringAppointments: appointments.filter(app => app.isRecurring).length
    };
  };

  return {
    appointments,
    waitingList,
    reminders,
    createAppointment,
    updateAppointment,
    deleteAppointment,
    changeStatus,
    getAppointmentById,
    getAvailableSlots,
    getStats,
    getAdvancedStats,
    reorderAppointments,
    // Waiting List
    addToWaitingList,
    removeFromWaitingList,
    promoteFromWaitingList,
    // Reminders
    scheduleReminder,
    cancelReminder,
    // History
    getClientHistory,
    getAllClients
  };
};
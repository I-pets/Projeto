import { useState } from "react";
import { Search, Plus, Filter, MoreHorizontal, Package, AlertTriangle, TrendingUp, ShoppingCart, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const Produtos = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("todas");
  const [stockFilter, setStockFilter] = useState("todos");
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const [formData, setFormData] = useState({
    nome: "",
    categoria: "",
    precoCompra: "",
    precoVenda: "",
    estoque: "",
    estoqueMinimo: "",
    fornecedor: "",
    descricao: ""
  });

  const [produtos, setProdutos] = useState([
    {
      id: 1,
      nome: "Ração Premium Adulto",
      categoria: "Ração",
      precoCompra: 45.90,
      precoVenda: 89.90,
      estoque: 25,
      estoqueMinimo: 10,
      fornecedor: "Pet Food Ltda",
      descricao: "Ração super premium para cães adultos",
      status: "ativo"
    },
    {
      id: 2,
      nome: "Vacina V10",
      categoria: "Medicamento",
      precoCompra: 35.00,
      precoVenda: 65.00,
      estoque: 5,
      estoqueMinimo: 8,
      fornecedor: "Veterinária Distribuidora",
      descricao: "Vacina polivalente para cães",
      status: "baixo_estoque"
    },
    {
      id: 3,
      nome: "Coleira Antipulgas",
      categoria: "Acessório",
      precoCompra: 12.50,
      precoVenda: 24.90,
      estoque: 15,
      estoqueMinimo: 5,
      fornecedor: "Pet Acessórios SA",
      descricao: "Coleira com proteção antipulgas 6 meses",
      status: "ativo"
    },
    {
      id: 4,
      nome: "Shampoo Neutro",
      categoria: "Higiene",
      precoCompra: 8.90,
      precoVenda: 18.50,
      estoque: 0,
      estoqueMinimo: 12,
      fornecedor: "Cosméticos Pet",
      descricao: "Shampoo neutro para todos os tipos de pelo",
      status: "sem_estoque"
    },
    {
      id: 5,
      nome: "Brinquedo Mordedor",
      categoria: "Brinquedo",
      precoCompra: 5.90,
      precoVenda: 14.90,
      estoque: 30,
      estoqueMinimo: 10,
      fornecedor: "Brinquedos & Cia",
      descricao: "Brinquedo resistente para cães de grande porte",
      status: "ativo"
    }
  ]);

  const categorias = ["Ração", "Medicamento", "Acessório", "Higiene", "Brinquedo"];

  const getStatusBadge = (produto: any) => {
    if (produto.estoque === 0) {
      return <Badge variant="destructive">Sem Estoque</Badge>;
    } else if (produto.estoque <= produto.estoqueMinimo) {
      return <Badge variant="outline" className="border-warning text-warning">Estoque Baixo</Badge>;
    } else {
      return <Badge variant="outline" className="border-success text-success">Em Estoque</Badge>;
    }
  };

  const handleSubmitProduto = () => {
    if (!formData.nome || !formData.categoria || !formData.precoVenda) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha nome, categoria e preço de venda",
        variant: "destructive"
      });
      return;
    }

    const novoProduto = {
      id: produtos.length + 1,
      nome: formData.nome,
      categoria: formData.categoria,
      precoCompra: parseFloat(formData.precoCompra) || 0,
      precoVenda: parseFloat(formData.precoVenda),
      estoque: parseInt(formData.estoque) || 0,
      estoqueMinimo: parseInt(formData.estoqueMinimo) || 5,
      fornecedor: formData.fornecedor || "Não informado",
      descricao: formData.descricao,
      status: "ativo"
    };

    setProdutos(prev => [...prev, novoProduto]);
    setFormData({
      nome: "",
      categoria: "",
      precoCompra: "",
      precoVenda: "",
      estoque: "",
      estoqueMinimo: "",
      fornecedor: "",
      descricao: ""
    });
    setIsDialogOpen(false);

    toast({
      title: "Produto Cadastrado",
      description: `${formData.nome} foi cadastrado com sucesso!`,
    });
  };

  const handleEditProduto = (produtoId: number) => {
    toast({
      title: "Editar Produto",
      description: `Editando produto #${produtoId}`,
    });
  };

  const handleDeleteProduto = (produtoId: number) => {
    setProdutos(prev => prev.filter(produto => produto.id !== produtoId));
    toast({
      title: "Produto Excluído",
      description: "Produto removido com sucesso",
      variant: "destructive",
    });
  };

  const filteredProdutos = produtos.filter(produto => {
    const matchesSearch = produto.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         produto.categoria.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         produto.fornecedor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === "todas" || produto.categoria === categoryFilter;
    
    let matchesStock = true;
    if (stockFilter === "baixo_estoque") {
      matchesStock = produto.estoque <= produto.estoqueMinimo && produto.estoque > 0;
    } else if (stockFilter === "sem_estoque") {
      matchesStock = produto.estoque === 0;
    } else if (stockFilter === "em_estoque") {
      matchesStock = produto.estoque > produto.estoqueMinimo;
    }

    return matchesSearch && matchesCategory && matchesStock;
  });

  const stats = {
    total: produtos.length,
    baixoEstoque: produtos.filter(p => p.estoque <= p.estoqueMinimo && p.estoque > 0).length,
    semEstoque: produtos.filter(p => p.estoque === 0).length,
    valorTotal: produtos.reduce((acc, p) => acc + (p.precoVenda * p.estoque), 0)
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Produtos & Estoque</h1>
          <p className="text-muted-foreground">Gerencie o estoque e produtos do seu petshop</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-primary hover:bg-gradient-primary/90 text-white shadow-soft">
              <Plus className="mr-2 h-4 w-4" />
              Novo Produto
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Cadastrar Novo Produto</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome do Produto *</Label>
                  <Input
                    value={formData.nome}
                    onChange={(e) => setFormData(prev => ({...prev, nome: e.target.value}))}
                    placeholder="Ex: Ração Premium..."
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="categoria">Categoria *</Label>
                  <Select value={formData.categoria} onValueChange={(value) => setFormData(prev => ({...prev, categoria: value}))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      {categorias.map((categoria) => (
                        <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="precoCompra">Preço de Compra</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.precoCompra}
                    onChange={(e) => setFormData(prev => ({...prev, precoCompra: e.target.value}))}
                    placeholder="0,00"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="precoVenda">Preço de Venda *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.precoVenda}
                    onChange={(e) => setFormData(prev => ({...prev, precoVenda: e.target.value}))}
                    placeholder="0,00"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="estoque">Estoque Atual</Label>
                  <Input
                    type="number"
                    value={formData.estoque}
                    onChange={(e) => setFormData(prev => ({...prev, estoque: e.target.value}))}
                    placeholder="0"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="estoqueMinimo">Estoque Mínimo</Label>
                  <Input
                    type="number"
                    value={formData.estoqueMinimo}
                    onChange={(e) => setFormData(prev => ({...prev, estoqueMinimo: e.target.value}))}
                    placeholder="5"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="fornecedor">Fornecedor</Label>
                <Input
                  value={formData.fornecedor}
                  onChange={(e) => setFormData(prev => ({...prev, fornecedor: e.target.value}))}
                  placeholder="Nome do fornecedor..."
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="descricao">Descrição</Label>
                <Textarea
                  value={formData.descricao}
                  onChange={(e) => setFormData(prev => ({...prev, descricao: e.target.value}))}
                  placeholder="Descrição detalhada do produto..."
                  rows={3}
                />
              </div>
              
              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setIsDialogOpen(false)}
                >
                  Cancelar
                </Button>
                <Button
                  className="flex-1 bg-gradient-primary hover:opacity-90"
                  onClick={handleSubmitProduto}
                >
                  Cadastrar Produto
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="shadow-soft hover:shadow-medium transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total de Produtos</p>
                <p className="text-2xl font-bold text-primary">{stats.total}</p>
              </div>
              <div className="p-3 rounded-lg bg-primary/10">
                <Package className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-soft hover:shadow-medium transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Estoque Baixo</p>
                <p className="text-2xl font-bold text-warning">{stats.baixoEstoque}</p>
              </div>
              <div className="p-3 rounded-lg bg-warning/10">
                <AlertTriangle className="h-6 w-6 text-warning" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-soft hover:shadow-medium transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Sem Estoque</p>
                <p className="text-2xl font-bold text-destructive">{stats.semEstoque}</p>
              </div>
              <div className="p-3 rounded-lg bg-destructive/10">
                <AlertTriangle className="h-6 w-6 text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-soft hover:shadow-medium transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Valor Total</p>
                <p className="text-2xl font-bold text-success">R$ {stats.valorTotal.toFixed(2)}</p>
              </div>
              <div className="p-3 rounded-lg bg-success/10">
                <TrendingUp className="h-6 w-6 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="text-lg">Lista de Produtos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Buscar por nome, categoria ou fornecedor..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas Categorias</SelectItem>
                {categorias.map(categoria => (
                  <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={stockFilter} onValueChange={setStockFilter}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos Estoques</SelectItem>
                <SelectItem value="em_estoque">Em Estoque</SelectItem>
                <SelectItem value="baixo_estoque">Estoque Baixo</SelectItem>
                <SelectItem value="sem_estoque">Sem Estoque</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="rounded-lg border border-border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/30">
                  <TableHead>Produto</TableHead>
                  <TableHead className="text-center">Categoria</TableHead>
                  <TableHead className="text-center">Estoque</TableHead>
                  <TableHead className="text-center">Preço Compra</TableHead>
                  <TableHead className="text-center">Preço Venda</TableHead>
                  <TableHead className="text-center">Fornecedor</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                  <TableHead className="text-center">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProdutos.map((produto) => (
                  <TableRow key={produto.id} className="hover:bg-muted/20 transition-colors">
                    <TableCell>
                      <div>
                        <div className="font-medium">{produto.nome}</div>
                        {produto.descricao && (
                          <div className="text-sm text-muted-foreground">{produto.descricao}</div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="outline">{produto.categoria}</Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="font-medium">
                        {produto.estoque}
                        <span className="text-sm text-muted-foreground"> / min: {produto.estoqueMinimo}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      R$ {produto.precoCompra.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="font-medium text-success">R$ {produto.precoVenda.toFixed(2)}</div>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="text-sm">{produto.fornecedor}</div>
                    </TableCell>
                    <TableCell className="text-center">
                      {getStatusBadge(produto)}
                    </TableCell>
                    <TableCell className="text-center">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Ações</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleEditProduto(produto.id)}>
                            <Package className="mr-2 h-4 w-4" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDeleteProduto(produto.id)}>
                            <Trash2 className="mr-2 h-4 w-4" />
                            Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Produtos;
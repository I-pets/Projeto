import { useState } from "react";
import { BarChart3, TrendingUp, DollarSign, Calendar, Download, Filter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const Relatorios = () => {
  const { toast } = useToast();
  const [selectedPeriod, setSelectedPeriod] = useState("mes");

  const handleExportReport = () => {
    toast({
      title: "Relatório Exportado",
      description: `Relatório do período "${selectedPeriod}" exportado com sucesso!`,
    });
  };

  const handlePeriodChange = (period: string) => {
    setSelectedPeriod(period);
    toast({
      title: "Período Alterado",
      description: `Visualizando dados do período: ${period}`,
    });
  };

  // Dados simulados para os gráficos
  const monthlyRevenue = [
    { month: "Jan", revenue: 12500, appointments: 85 },
    { month: "Fev", revenue: 15200, appointments: 92 },
    { month: "Mar", revenue: 18750, appointments: 108 },
    { month: "Abr", revenue: 16300, appointments: 98 },
    { month: "Mai", revenue: 19800, appointments: 115 },
    { month: "Jun", revenue: 22400, appointments: 128 },
  ];

  const serviceDistribution = [
    { name: "Consultas", value: 35, color: "hsl(183 100% 35%)" },
    { name: "Banho e Tosa", value: 28, color: "hsl(160 60% 45%)" },
    { name: "Vacinação", value: 20, color: "hsl(25 95% 60%)" },
    { name: "Cirurgias", value: 10, color: "hsl(45 93% 47%)" },
    { name: "Outros", value: 7, color: "hsl(210 40% 60%)" },
  ];

  const dailyAppointments = [
    { day: "Seg", appointments: 18 },
    { day: "Ter", appointments: 22 },
    { day: "Qua", appointments: 25 },
    { day: "Qui", appointments: 20 },
    { day: "Sex", appointments: 28 },
    { day: "Sáb", appointments: 35 },
    { day: "Dom", appointments: 12 },
  ];

  const topClients = [
    { name: "Maria Silva", appointments: 12, revenue: "R$ 1.850" },
    { name: "João Santos", appointments: 8, revenue: "R$ 1.200" },
    { name: "Ana Costa", appointments: 7, revenue: "R$ 980" },
    { name: "Carlos Lima", appointments: 6, revenue: "R$ 750" },
    { name: "Paula Rocha", appointments: 5, revenue: "R$ 650" },
  ];

  const kpis = [
    {
      title: "Faturamento Total",
      value: "R$ 22.400",
      change: "+12,5%",
      trend: "up",
      icon: DollarSign,
      color: "text-success"
    },
    {
      title: "Agendamentos",
      value: "128",
      change: "+8,2%",
      trend: "up",
      icon: Calendar,
      color: "text-primary"
    },
    {
      title: "Ticket Médio",
      value: "R$ 175",
      change: "+3,8%",
      trend: "up",
      icon: TrendingUp,
      color: "text-accent"
    },
    {
      title: "Taxa de Cancelamento",
      value: "4,2%",
      change: "-1,5%",
      trend: "down",
      icon: BarChart3,
      color: "text-destructive"
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Relatórios Financeiros</h1>
          <p className="text-muted-foreground">Acompanhe o desempenho do seu petshop</p>
        </div>
        
        <div className="flex gap-2">
          <Select value={selectedPeriod} onValueChange={handlePeriodChange}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="semana">Esta Semana</SelectItem>
              <SelectItem value="mes">Este Mês</SelectItem>
              <SelectItem value="trimestre">Trimestre</SelectItem>
              <SelectItem value="ano">Este Ano</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={handleExportReport}>
            <Download className="mr-2 h-4 w-4" />
            Exportar
          </Button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi, index) => (
          <Card key={index} className="shadow-soft hover:shadow-medium transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{kpi.title}</p>
                  <p className="text-2xl font-bold mt-1">{kpi.value}</p>
                  <div className="flex items-center mt-2">
                    <Badge 
                      variant="outline" 
                      className={kpi.trend === "up" ? "text-success border-success/30 bg-success/10" : "text-destructive border-destructive/30 bg-destructive/10"}
                    >
                      {kpi.change}
                    </Badge>
                  </div>
                </div>
                <div className={`p-3 rounded-lg bg-muted/30`}>
                  <kpi.icon className={`h-6 w-6 ${kpi.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Evolução do Faturamento
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyRevenue}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "hsl(var(--card))", 
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "0.75rem"
                  }} 
                />
                <Line 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={3}
                  dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Service Distribution */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-secondary" />
              Distribuição de Serviços
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={serviceDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {serviceDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-2 gap-2 mt-4">
              {serviceDistribution.map((service, index) => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: service.color }}
                  />
                  <span className="text-muted-foreground">{service.name}</span>
                  <span className="font-medium">{service.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Daily Appointments */}
        <Card className="lg:col-span-2 shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-accent" />
              Agendamentos por Dia da Semana
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={dailyAppointments}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "hsl(var(--card))", 
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "0.75rem"
                  }} 
                />
                <Bar 
                  dataKey="appointments" 
                  fill="hsl(var(--accent))"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Top Clients */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="text-lg">Top Clientes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topClients.map((client, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                  <div>
                    <p className="font-medium text-sm">{client.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {client.appointments} agendamentos
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-sm text-success">{client.revenue}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="shadow-soft">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-primary mb-2">248</div>
            <p className="text-sm text-muted-foreground">Clientes Ativos</p>
            <p className="text-xs text-success mt-1">+12 este mês</p>
          </CardContent>
        </Card>
        <Card className="shadow-soft">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-secondary mb-2">456</div>
            <p className="text-sm text-muted-foreground">Pets Cadastrados</p>
            <p className="text-xs text-success mt-1">+18 este mês</p>
          </CardContent>
        </Card>
        <Card className="shadow-soft">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-accent mb-2">95%</div>
            <p className="text-sm text-muted-foreground">Satisfação Cliente</p>
            <p className="text-xs text-success mt-1">+2% este mês</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Relatorios;
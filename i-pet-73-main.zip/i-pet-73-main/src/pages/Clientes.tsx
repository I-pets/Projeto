import { useState } from "react";
import { Search, Plus, Filter, MoreHorizontal, Phone, Mail, Edit, Trash2, Users, MapPin, PawPrint, CheckCircle, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { PetForm } from "@/components/PetForm";

const Clientes = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<any>(null);
  
  // Estados do formulário
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    telefone: "",
    endereco: "",
    cidade: "",
    cep: "",
    observacoes: "",
    pets: [{ nome: "", especie: "", raca: "", idade: "", peso: "", cor: "", observacoesMedicas: "" }]
  });
  const [clientes, setClientes] = useState([

    {
      id: 1,
      nome: "Maria Silva",
      email: "maria@email.com",
      telefone: "(11) 99999-1111",
      pets: [
        { nome: "Rex", especie: "Cão", raca: "Golden Retriever", idade: "3 anos", peso: "30kg", cor: "Dourado", observacoesMedicas: "Alergia a ração de frango" },
        { nome: "Mimi", especie: "Gato", raca: "Persa", idade: "2 anos", peso: "4kg", cor: "Branco", observacoesMedicas: "Vacinas em dia" }
      ],
      ultimaVisita: "2024-01-15",
      totalGasto: "R$ 1.850",
      status: "ativo",
      cidade: "São Paulo",
      endereco: "Rua das Flores, 123 - Centro",
      cep: "01310-100",
      observacoes: "Cliente VIP"
    },
    {
      id: 2,
      nome: "João Santos",
      email: "joao@email.com",
      telefone: "(11) 99999-2222",
      pets: [
        { nome: "Thor", especie: "Cão", raca: "Labrador", idade: "5 anos", peso: "35kg", cor: "Preto", observacoesMedicas: "Displasia de quadril" }
      ],
      ultimaVisita: "2024-01-10",
      totalGasto: "R$ 1.200",
      status: "ativo",
      cidade: "Guarulhos",
      endereco: "Av. Paulista, 456 - Bela Vista",
      cep: "07020-000",
      observacoes: "Cliente desde 2020"
    },
    {
      id: 3,
      nome: "Ana Costa",
      email: "ana@email.com",
      telefone: "(11) 99999-3333",
      pets: [
        { nome: "Luna", especie: "Gato", raca: "SRD", idade: "1 ano", peso: "3kg", cor: "Cinza", observacoesMedicas: "Castrada" },
        { nome: "Buddy", especie: "Cão", raca: "Shih Tzu", idade: "4 anos", peso: "6kg", cor: "Marrom", observacoesMedicas: "Problema cardíaco" },
        { nome: "Mel", especie: "Cão", raca: "Poodle", idade: "7 anos", peso: "8kg", cor: "Branco", observacoesMedicas: "Idoso, cuidados especiais" }
      ],
      ultimaVisita: "2023-12-20",
      totalGasto: "R$ 980",
      status: "inativo",
      cidade: "Osasco",
      endereco: "Rua dos Bandeirantes, 789 - Centro",
      cep: "06010-000",
      observacoes: "Última consulta há 3 meses"
    },
    {
      id: 4,
      nome: "Carlos Lima",
      email: "carlos@email.com",
      telefone: "(11) 99999-4444",
      pets: [
        { nome: "Bolt", especie: "Cão", raca: "Border Collie", idade: "2 anos", peso: "20kg", cor: "Preto e branco", observacoesMedicas: "Muito ativo, cuidado com exercícios" }
      ],
      ultimaVisita: "2024-01-12",
      totalGasto: "R$ 750",
      status: "ativo",
      cidade: "São Paulo",
      endereco: "Alameda Santos, 321 - Jardins",
      cep: "01419-000",
      observacoes: "Agendamentos preferenciais pela manhã"
    },
    {
      id: 5,
      nome: "Paula Rocha",
      email: "paula@email.com",
      telefone: "(11) 99999-5555",
      pets: [
        { nome: "Coco", especie: "Cão", raca: "Yorkshise Terrier", idade: "3 anos", peso: "3kg", cor: "Marrom", observacoesMedicas: "Luxação de patela" },
        { nome: "Nala", especie: "Gato", raca: "Siamês", idade: "1 ano", peso: "3.5kg", cor: "Chocolate point", observacoesMedicas: "Primeira consulta" }
      ],
      ultimaVisita: "2024-01-08",
      totalGasto: "R$ 650",
      status: "ativo",
      cidade: "Barueri",
      endereco: "Rua das Palmeiras, 567 - Alphaville",
      cep: "06453-070",
      observacoes: "Preferência por veterinário Dr. Silva"
    },
  ]);

  const handleSubmitCliente = () => {
    if (!formData.nome || !formData.email || !formData.telefone) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha nome, email e telefone",
        variant: "destructive"
      });
      return;
    }

    if (editingClient) {
      // Editando cliente existente
      const updatedCliente = {
        ...editingClient,
        nome: formData.nome,
        email: formData.email,
        telefone: formData.telefone,
        pets: formData.pets.filter(pet => pet.nome),
        cidade: formData.cidade || "Não informado",
        endereco: formData.endereco,
        cep: formData.cep,
        observacoes: formData.observacoes
      };

      setClientes(prev => prev.map(cliente => 
        cliente.id === editingClient.id ? updatedCliente : cliente
      ));

      toast({
        title: "Cliente Atualizado",
        description: `${formData.nome} foi atualizado com sucesso!`,
      });
    } else {
      // Criando novo cliente
      const newCliente = {
        id: clientes.length + 1,
        nome: formData.nome,
        email: formData.email,
        telefone: formData.telefone,
        pets: formData.pets.filter(pet => pet.nome),
        ultimaVisita: new Date().toISOString().split('T')[0],
        totalGasto: "R$ 0",
        status: "ativo",
        cidade: formData.cidade || "Não informado",
        endereco: formData.endereco,
        cep: formData.cep,
        observacoes: formData.observacoes
      };

      setClientes(prev => [...prev, newCliente]);

      toast({
        title: "Cliente Cadastrado",
        description: `${formData.nome} foi cadastrado com sucesso!`,
      });
    }

    // Reset form
    setFormData({
      nome: "",
      email: "",
      telefone: "",
      endereco: "",
      cidade: "",
      cep: "",
      observacoes: "",
      pets: [{ nome: "", especie: "", raca: "", idade: "", peso: "", cor: "", observacoesMedicas: "" }]
    });
    setEditingClient(null);
    setIsDialogOpen(false);
  };


  const handleEditCliente = (clienteId: number) => {
    const cliente = clientes.find(c => c.id === clienteId);
    if (cliente) {
      setEditingClient(cliente);
      setFormData({
        nome: cliente.nome,
        email: cliente.email,
        telefone: cliente.telefone,
        endereco: cliente.endereco || "",
        cidade: cliente.cidade || "",
        cep: cliente.cep || "",
        observacoes: cliente.observacoes || "",
        pets: cliente.pets.length > 0 ? cliente.pets : [{ nome: "", especie: "", raca: "", idade: "", peso: "", cor: "", observacoesMedicas: "" }]
      });
      setIsDialogOpen(true);
    }
  };

  const handleDeleteCliente = (clienteId: number) => {
    setClientes(prev => prev.filter(cliente => cliente.id !== clienteId));
    toast({
      title: "Cliente Excluído",
      description: "Cliente removido com sucesso",
      variant: "destructive",
    });
  };

  const handleChangeStatus = (clienteId: number, newStatus: string) => {
    setClientes(prev => 
      prev.map(cliente => 
        cliente.id === clienteId 
          ? { ...cliente, status: newStatus }
          : cliente
      )
    );
    toast({
      title: "Status Alterado",
      description: `Status do cliente alterado para ${newStatus}`,
    });
  };

  const handleCallClient = (clienteNome: string, telefone: string) => {
    // Remove caracteres especiais do telefone para o link tel:
    const cleanPhone = telefone.replace(/\D/g, '');
    window.open(`tel:+55${cleanPhone}`, '_self');
    toast({
      title: "Ligando para Cliente",
      description: `Ligando para ${clienteNome}`,
    });
  };

  const handleEmailClient = (clienteNome: string, email: string) => {
    const subject = `Contato - ${clienteNome}`;
    const body = `Olá ${clienteNome},%0D%0A%0D%0AEsperamos que você e seu pet estejam bem!%0D%0A%0D%0AAtenciosamente,%0D%0AEquipe iPet`;
    window.open(`mailto:${email}?subject=${subject}&body=${body}`, '_self');
    toast({
      title: "Abrindo Email",
      description: `Abrindo cliente de email para ${clienteNome}`,
    });
  };

  const filteredClientes = clientes.filter(cliente => {
    const matchesSearch = cliente.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         cliente.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         cliente.cidade.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "todos" || cliente.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: clientes.length,
    ativos: clientes.filter(c => c.status === "ativo").length,
    inativos: clientes.filter(c => c.status === "inativo").length,
    totalPets: clientes.reduce((acc, c) => acc + c.pets.length, 0)
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Gerenciar Clientes</h1>
          <p className="text-muted-foreground">Gerencie seus clientes e seus pets</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-primary hover:bg-gradient-primary/90 text-white shadow-soft">
              <Plus className="mr-2 h-4 w-4" />
              Novo Cliente
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingClient ? 'Editar Cliente' : 'Cadastrar Novo Cliente'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nome">Nome Completo *</Label>
                  <Input
                    value={formData.nome}
                    onChange={(e) => setFormData(prev => ({...prev, nome: e.target.value}))}
                    placeholder="Ex: Maria Silva"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({...prev, email: e.target.value}))}
                    placeholder="maria@email.com"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone *</Label>
                  <Input
                    value={formData.telefone}
                    onChange={(e) => setFormData(prev => ({...prev, telefone: e.target.value}))}
                    placeholder="(11) 99999-9999"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cidade">Cidade</Label>
                  <Input
                    value={formData.cidade}
                    onChange={(e) => setFormData(prev => ({...prev, cidade: e.target.value}))}
                    placeholder="São Paulo"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="cep">CEP</Label>
                  <Input
                    value={formData.cep}
                    onChange={(e) => setFormData(prev => ({...prev, cep: e.target.value}))}
                    placeholder="00000-000"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="endereco">Endereço Completo</Label>
                <Input
                  value={formData.endereco}
                  onChange={(e) => setFormData(prev => ({...prev, endereco: e.target.value}))}
                  placeholder="Rua, número, bairro..."
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="observacoes">Observações</Label>
                <Textarea
                  value={formData.observacoes}
                  onChange={(e) => setFormData(prev => ({...prev, observacoes: e.target.value}))}
                  placeholder="Informações adicionais sobre o cliente..."
                  rows={3}
                />
              </div>
              
              <PetForm 
                pets={formData.pets}
                onChange={(pets) => setFormData(prev => ({...prev, pets}))}
              />
              
              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    setIsDialogOpen(false);
                    setEditingClient(null);
                    setFormData({
                      nome: "",
                      email: "",
                      telefone: "",
                      endereco: "",
                      cidade: "",
                      cep: "",
                      observacoes: "",
                      pets: [{ nome: "", especie: "", raca: "", idade: "", peso: "", cor: "", observacoesMedicas: "" }]
                    });
                  }}
                >
                  Cancelar
                </Button>
                <Button
                  className="flex-1 bg-gradient-primary hover:opacity-90"
                  onClick={handleSubmitCliente}
                >
                  {editingClient ? 'Atualizar Cliente' : 'Cadastrar Cliente'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="shadow-soft hover:shadow-medium transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total de Clientes</p>
                <p className="text-2xl font-bold text-primary">{stats.total}</p>
              </div>
              <div className="p-3 rounded-lg bg-primary/10">
                <Users className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-soft hover:shadow-medium transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Clientes Ativos</p>
                <p className="text-2xl font-bold text-success">{stats.ativos}</p>
              </div>
              <div className="p-3 rounded-lg bg-success/10">
                <Users className="h-6 w-6 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-soft hover:shadow-medium transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Clientes Inativos</p>
                <p className="text-2xl font-bold text-destructive">{stats.inativos}</p>
              </div>
              <div className="p-3 rounded-lg bg-destructive/10">
                <Users className="h-6 w-6 text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-soft hover:shadow-medium transition-all duration-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total de Pets</p>
                <p className="text-2xl font-bold text-accent">{stats.totalPets}</p>
              </div>
              <div className="p-3 rounded-lg bg-accent/10">
                <Users className="h-6 w-6 text-accent" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="text-lg">Lista de Clientes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Buscar por nome ou email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos Status</SelectItem>
                <SelectItem value="ativo">Ativos</SelectItem>
                <SelectItem value="inativo">Inativos</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={() => toast({title: "Filtros", description: "Filtros avançados serão implementados em breve"})}>
              <Filter className="mr-2 h-4 w-4" />
              Filtros
            </Button>
          </div>

          <div className="rounded-lg border border-border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/30">
                  <TableHead className="min-w-[180px]">Cliente</TableHead>
                  <TableHead className="min-w-[220px] hidden sm:table-cell">Contato</TableHead>
                  <TableHead className="min-w-[140px]">Pets</TableHead>
                  <TableHead className="min-w-[120px] hidden md:table-cell">Última Visita</TableHead>
                  <TableHead className="min-w-[100px] hidden md:table-cell">Total Gasto</TableHead>
                  <TableHead className="min-w-[120px] text-center">Status</TableHead>
                  <TableHead className="min-w-[80px] text-center">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredClientes.map((cliente) => (
                  <TableRow key={cliente.id} className="hover:bg-muted/20 transition-colors">
                    <TableCell className="min-w-[180px]">
                      <div className="space-y-1">
                        <div className="font-medium">{cliente.nome}</div>
                        <div className="text-sm text-muted-foreground flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {cliente.cidade}
                        </div>
                        {/* Mostrar contato em mobile */}
                        <div className="sm:hidden space-y-1 pt-1">
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Phone className="h-3 w-3" />
                            {cliente.telefone}
                          </div>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Mail className="h-3 w-3" />
                            {cliente.email}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="min-w-[220px] hidden sm:table-cell">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-sm">
                          <Phone className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                          <span className="truncate">{cliente.telefone}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Mail className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                          <span className="truncate">{cliente.email}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="min-w-[140px]">
                      <div className="space-y-2">
                        <Badge variant="outline" className="text-accent border-accent/30 bg-accent/10 whitespace-nowrap">
                          {cliente.pets.length} {cliente.pets.length === 1 ? 'pet' : 'pets'}
                        </Badge>
                        {cliente.pets.length > 0 && (
                          <div className="text-xs text-muted-foreground max-w-[120px]">
                            {cliente.pets.slice(0, 1).map((pet, index) => (
                              <div key={index} className="flex items-center gap-1 truncate">
                                <PawPrint className="h-3 w-3 flex-shrink-0" />
                                <span className="truncate">{pet.nome}</span>
                              </div>
                            ))}
                            {cliente.pets.length > 1 && (
                              <div className="text-xs text-muted-foreground">
                                +{cliente.pets.length - 1} mais
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="min-w-[120px] hidden md:table-cell">
                      <div className="text-sm whitespace-nowrap">
                        {new Date(cliente.ultimaVisita).toLocaleDateString('pt-BR')}
                      </div>
                    </TableCell>
                    <TableCell className="min-w-[100px] hidden md:table-cell">
                      <div className="font-medium text-success whitespace-nowrap">{cliente.totalGasto}</div>
                    </TableCell>
                    <TableCell className="min-w-[120px]">
                      <div className="flex justify-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="p-0 h-auto hover:bg-transparent">
                              <Badge 
                                className={`cursor-pointer transition-all duration-200 hover:opacity-80 whitespace-nowrap ${
                                  cliente.status === 'ativo' 
                                    ? 'bg-success text-success-foreground hover:bg-success/80' 
                                    : 'bg-destructive text-destructive-foreground hover:bg-destructive/80'
                                }`}
                              >
                                {cliente.status === 'ativo' ? (
                                  <CheckCircle className="mr-1 h-3 w-3" />
                                ) : (
                                  <XCircle className="mr-1 h-3 w-3" />
                                )}
                                {cliente.status === 'ativo' ? 'Ativo' : 'Inativo'}
                              </Badge>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="center">
                            <DropdownMenuLabel>Alterar Status</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleChangeStatus(cliente.id, 'ativo')}>
                              <CheckCircle className="mr-2 h-4 w-4 text-success" />
                              Ativo
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleChangeStatus(cliente.id, 'inativo')}>
                              <XCircle className="mr-2 h-4 w-4 text-destructive" />
                              Inativo
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                      {/* Mostrar info adicional em mobile */}
                      <div className="md:hidden mt-2 space-y-1 text-xs text-muted-foreground">
                        <div>Última: {new Date(cliente.ultimaVisita).toLocaleDateString('pt-BR')}</div>
                        <div className="font-medium text-success">{cliente.totalGasto}</div>
                      </div>
                    </TableCell>
                    <TableCell className="min-w-[80px]">
                      <div className="flex justify-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Ações</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleEditCliente(cliente.id)}>
                              <Edit className="mr-2 h-4 w-4" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleCallClient(cliente.nome, cliente.telefone)}>
                              <Phone className="mr-2 h-4 w-4" />
                              Ligar
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEmailClient(cliente.nome, cliente.email)}>
                              <Mail className="mr-2 h-4 w-4" />
                              Enviar Email
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-destructive" onClick={() => handleDeleteCliente(cliente.id)}>
                              <Trash2 className="mr-2 h-4 w-4" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Clientes;
import { useState } from "react";
import { Calendar, Plus, Search, Filter, Clock, User, Heart } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import AppointmentForm from "@/components/AppointmentForm";
import AppointmentViews from "@/components/AppointmentViews";
import ConfirmDialog from "@/components/ConfirmDialog";
import WaitingListManager from "@/components/WaitingListManager";
import ClientHistory from "@/components/ClientHistory";
import { useAppointments, type AppointmentFormData, type Appointment } from "@/hooks/useAppointments";
import { useToast } from "@/hooks/use-toast";
const Agendamentos = () => {
  const {
    toast
  } = useToast();
  const {
    appointments,
    createAppointment,
    updateAppointment,
    deleteAppointment,
    changeStatus,
    getAppointmentById,
    getAvailableSlots,
    getStats,
    reorderAppointments
  } = useAppointments();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [serviceFilter, setServiceFilter] = useState("todos");
  const [dateFilter, setDateFilter] = useState("hoje");
  const [timeFilter, setTimeFilter] = useState("todos");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{
    isOpen: boolean;
    id: number | null;
  }>({
    isOpen: false,
    id: null
  });
  const [formData, setFormData] = useState<AppointmentFormData>({
    client: "",
    pet: "",
    breed: "",
    service: "",
    serviceCategory: "consultas",
    date: new Date(),
    time: "",
    phone: "",
    notes: "",
    staff: ""
  });
  const resetForm = () => {
    setFormData({
      client: "",
      pet: "",
      breed: "",
      service: "",
      serviceCategory: "consultas",
      date: new Date(),
      time: "",
      phone: "",
      notes: "",
      staff: ""
    });
    setEditingId(null);
  };
  const handleSubmitAgendamento = () => {
    console.log("Submit button clicked");
    console.log("Form data:", formData);
    console.log("Editing ID:", editingId);
    const success = editingId ? updateAppointment(editingId, formData) : createAppointment(formData);
    console.log("Submit success:", success);
    if (success) {
      resetForm();
      setIsDialogOpen(false);
      toast({
        title: editingId ? "Agendamento atualizado" : "Agendamento criado",
        description: editingId ? `Agendamento de ${formData.client} foi atualizado com sucesso.` : `Novo agendamento para ${formData.client} foi criado com sucesso.`
      });
    }
  };
  const handleEditAppointment = (appointmentId: number) => {
    const appointment = getAppointmentById(appointmentId);
    if (appointment) {
      setFormData({
        client: appointment.client,
        pet: appointment.pet,
        breed: appointment.breed,
        service: appointment.service,
        serviceCategory: appointment.serviceCategory,
        date: appointment.date,
        time: appointment.time,
        phone: appointment.phone,
        notes: appointment.notes,
        staff: appointment.staff
      });
      setEditingId(appointmentId);
      setIsDialogOpen(true);
    }
  };
  const handleSelectAppointment = (appointment: Appointment) => {
    handleEditAppointment(appointment.id);
  };
  const handleSelectSlot = (time: string) => {
    setFormData({
      ...formData,
      time,
      date: selectedDate
    });
    setIsDialogOpen(true);
  };
  const handleDeleteAppointment = (appointmentId: number) => {
    setDeleteConfirm({
      isOpen: true,
      id: appointmentId
    });
  };
  const confirmDelete = () => {
    if (deleteConfirm.id) {
      deleteAppointment(deleteConfirm.id);
    }
    setDeleteConfirm({
      isOpen: false,
      id: null
    });
  };
  const handleDialogClose = () => {
    setIsDialogOpen(false);
    resetForm();
  };
  const availableSlots = getAvailableSlots(formData.date, editingId || undefined);
  const stats = getStats();
  const filteredAppointments = appointments.filter(appointment => {
    const matchesSearch = appointment.client.toLowerCase().includes(searchTerm.toLowerCase()) || appointment.pet.toLowerCase().includes(searchTerm.toLowerCase()) || appointment.service.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "todos" || appointment.status === statusFilter;
    const matchesService = serviceFilter === "todos" || appointment.service.toLowerCase().includes(serviceFilter.toLowerCase());

    // Date filter
    const today = format(new Date(), 'yyyy-MM-dd');
    const appointmentDate = format(appointment.date, 'yyyy-MM-dd');
    const matchesDate = dateFilter === "todos" || dateFilter === "hoje" && appointmentDate === today || dateFilter === "amanha" && appointmentDate === format(new Date(Date.now() + 24 * 60 * 60 * 1000), 'yyyy-MM-dd');

    // Time filter
    const matchesTime = timeFilter === "todos" || timeFilter === "manha" && appointment.time < "12:00" || timeFilter === "tarde" && appointment.time >= "12:00";
    return matchesSearch && matchesStatus && matchesService && matchesDate && matchesTime;
  });
  return <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Agendamentos</h1>
          <p className="text-muted-foreground">Gerencie os agendamentos do seu petshop</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={open => {
        console.log("Dialog open state changed:", open);
        if (open) {
          setIsDialogOpen(true);
        } else {
          handleDialogClose();
        }
      }}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-primary hover:opacity-90" size="lg" onClick={() => {
            console.log("Novo Agendamento button clicked");
            setIsDialogOpen(true);
          }}>
              <Plus className="mr-2 h-4 w-4" />
              Novo Agendamento
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingId ? "Editar Agendamento" : "Novo Agendamento"}
              </DialogTitle>
            </DialogHeader>
            <AppointmentForm formData={formData} setFormData={setFormData} onSubmit={handleSubmitAgendamento} onCancel={handleDialogClose} isEdit={!!editingId} availableSlots={availableSlots} />
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      

      {/* Enhanced Views with UX improvements */}
      <AppointmentViews appointments={appointments} filteredAppointments={filteredAppointments} selectedDate={selectedDate} onDateChange={setSelectedDate} availableSlots={availableSlots} searchQuery={searchTerm} onSearch={setSearchTerm} onStatusChange={changeStatus} onEdit={handleEditAppointment} onDelete={handleDeleteAppointment} onSelectAppointment={handleSelectAppointment} onSelectSlot={handleSelectSlot} onReorderAppointments={reorderAppointments} />

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="shadow-soft">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary mb-1">{stats.total}</div>
            <p className="text-xs text-muted-foreground">Total Hoje</p>
          </CardContent>
        </Card>
        <Card className="shadow-soft">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-success mb-1">{stats.confirmados}</div>
            <p className="text-xs text-muted-foreground">Confirmados</p>
          </CardContent>
        </Card>
        <Card className="shadow-soft">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-warning mb-1">{stats.em_andamento}</div>
            <p className="text-xs text-muted-foreground">Em Andamento</p>
          </CardContent>
        </Card>
        <Card className="shadow-soft">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-destructive mb-1">{stats.pendentes}</div>
            <p className="text-xs text-muted-foreground">Pendentes</p>
          </CardContent>
        </Card>
      </div>

      {/* Advanced Features */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <WaitingListManager />
        <ClientHistory />
      </div>
      
      <ConfirmDialog isOpen={deleteConfirm.isOpen} onClose={() => setDeleteConfirm({
      isOpen: false,
      id: null
    })} onConfirm={confirmDelete} title="Confirmar Exclusão" description="Tem certeza que deseja excluir este agendamento? Esta ação não pode ser desfeita." confirmText="Excluir" cancelText="Cancelar" variant="destructive" />
    </div>;
};
export default Agendamentos;
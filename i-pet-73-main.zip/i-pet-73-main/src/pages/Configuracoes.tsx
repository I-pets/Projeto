import { useState } from "react";
import { Save, Bell, Shield, User, Building, Palette, Globe, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";

const Configuracoes = () => {
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    // Configurações da Empresa
    nomeEmpresa: "I Pet - Petshop",
    endereco: "Rua das Flores, 123",
    cidade: "São Paulo",
    cep: "01234-567",
    telefone: "(11) 99999-0000",
    email: "contato@ipet.com.br",
    
    // Notificações
    notificacoesEmail: true,
    notificacoesSms: false,
    lembretesAgendamento: true,
    
    // Sistema
    fusoHorario: "America/Sao_Paulo",
    idioma: "pt-BR",
    formatoData: "DD/MM/YYYY",
    
    // Segurança
    autenticacaoDoisFatores: false,
    loginAutomatico: true,
    
    // Aparência
    temaEscuro: false,
    corPrimaria: "#0ea5e9",
  });

  const handleSave = () => {
    toast({
      title: "Configurações salvas",
      description: "Suas configurações foram atualizadas com sucesso.",
    });
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setSettings(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Configurações</h1>
          <p className="text-muted-foreground">Gerencie as configurações do sistema</p>
        </div>
        
        <Button onClick={handleSave} className="bg-gradient-primary hover:bg-gradient-primary/90 text-white shadow-soft">
          <Save className="mr-2 h-4 w-4" />
          Salvar Alterações
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Informações da Empresa */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="h-5 w-5 text-primary" />
              Informações da Empresa
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="nomeEmpresa">Nome da Empresa</Label>
                <Input
                  id="nomeEmpresa"
                  value={settings.nomeEmpresa}
                  onChange={(e) => handleInputChange("nomeEmpresa", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="telefone">Telefone</Label>
                <Input
                  id="telefone"
                  value={settings.telefone}
                  onChange={(e) => handleInputChange("telefone", e.target.value)}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="endereco">Endereço</Label>
              <Input
                id="endereco"
                value={settings.endereco}
                onChange={(e) => handleInputChange("endereco", e.target.value)}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="cidade">Cidade</Label>
                <Input
                  id="cidade"
                  value={settings.cidade}
                  onChange={(e) => handleInputChange("cidade", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cep">CEP</Label>
                <Input
                  id="cep"
                  value={settings.cep}
                  onChange={(e) => handleInputChange("cep", e.target.value)}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={settings.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Notificações */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-secondary" />
              Notificações
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Notificações por Email</Label>
                <p className="text-sm text-muted-foreground">
                  Receber notificações importantes por email
                </p>
              </div>
              <Switch
                checked={settings.notificacoesEmail}
                onCheckedChange={(checked) => handleInputChange("notificacoesEmail", checked)}
              />
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Notificações SMS</Label>
                <p className="text-sm text-muted-foreground">
                  Receber notificações por mensagem de texto
                </p>
              </div>
              <Switch
                checked={settings.notificacoesSms}
                onCheckedChange={(checked) => handleInputChange("notificacoesSms", checked)}
              />
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Lembretes de Agendamento</Label>
                <p className="text-sm text-muted-foreground">
                  Enviar lembretes automáticos aos clientes
                </p>
              </div>
              <Switch
                checked={settings.lembretesAgendamento}
                onCheckedChange={(checked) => handleInputChange("lembretesAgendamento", checked)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Sistema */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-accent" />
              Configurações do Sistema
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fusoHorario">Fuso Horário</Label>
              <Select value={settings.fusoHorario} onValueChange={(value) => handleInputChange("fusoHorario", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="America/Sao_Paulo">São Paulo (GMT-3)</SelectItem>
                  <SelectItem value="America/Manaus">Manaus (GMT-4)</SelectItem>
                  <SelectItem value="America/Rio_Branco">Rio Branco (GMT-5)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="idioma">Idioma</Label>
              <Select value={settings.idioma} onValueChange={(value) => handleInputChange("idioma", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pt-BR">Português (Brasil)</SelectItem>
                  <SelectItem value="en-US">English (US)</SelectItem>
                  <SelectItem value="es-ES">Español</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="formatoData">Formato de Data</Label>
              <Select value={settings.formatoData} onValueChange={(value) => handleInputChange("formatoData", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="DD/MM/YYYY">DD/MM/AAAA</SelectItem>
                  <SelectItem value="MM/DD/YYYY">MM/DD/AAAA</SelectItem>
                  <SelectItem value="YYYY-MM-DD">AAAA-MM-DD</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Segurança */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-destructive" />
              Segurança
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Autenticação de Dois Fatores</Label>
                <p className="text-sm text-muted-foreground">
                  Adicionar camada extra de segurança
                </p>
              </div>
              <Switch
                checked={settings.autenticacaoDoisFatores}
                onCheckedChange={(checked) => handleInputChange("autenticacaoDoisFatores", checked)}
              />
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Login Automático</Label>
                <p className="text-sm text-muted-foreground">
                  Manter sessão ativa por mais tempo
                </p>
              </div>
              <Switch
                checked={settings.loginAutomatico}
                onCheckedChange={(checked) => handleInputChange("loginAutomatico", checked)}
              />
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <Label>Alterar Senha</Label>
              <Button variant="outline" className="w-full">
                <User className="mr-2 h-4 w-4" />
                Alterar Senha
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Aparência */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Palette className="h-5 w-5 text-primary" />
            Aparência
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Tema Escuro</Label>
                <p className="text-sm text-muted-foreground">
                  Alternar entre tema claro e escuro
                </p>
              </div>
              <Switch
                checked={settings.temaEscuro}
                onCheckedChange={(checked) => handleInputChange("temaEscuro", checked)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="corPrimaria">Cor Primária</Label>
              <div className="flex gap-2">
                <Input
                  id="corPrimaria"
                  type="color"
                  value={settings.corPrimaria}
                  onChange={(e) => handleInputChange("corPrimaria", e.target.value)}
                  className="w-16 h-10 p-1"
                />
                <Input
                  value={settings.corPrimaria}
                  onChange={(e) => handleInputChange("corPrimaria", e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Configuracoes;
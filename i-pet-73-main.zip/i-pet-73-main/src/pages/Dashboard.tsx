import { Calendar, Users, Heart, DollarSign, TrendingUp, Clock, ExternalLink } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import heroImage from "@/assets/petshop-hero.jpg";

const Dashboard = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const today = new Date().toLocaleDateString('pt-BR', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  const handleNovoAgendamento = () => {
    navigate('/agendamentos');
    toast({
      title: "Novo Agendamento",
      description: "Redirecionado para a página de agendamentos",
    });
  };

  const handleCadastrarCliente = () => {
    navigate('/clientes');
    toast({
      title: "Cadastrar Cliente",
      description: "Redirecionado para a página de clientes",
    });
  };

  const handleCadastrarPet = () => {
    navigate('/clientes');
    toast({
      title: "Cadastrar Pet",
      description: "Redirecionado para a página de clientes",
    });
  };

  const handleVerRelatorios = () => {
    navigate('/relatorios');
    toast({
      title: "Relatórios",
      description: "Redirecionado para a página de relatórios",
    });
  };

  const handlePortalCliente = () => {
    navigate('/portal');
    toast({
      title: "Portal do Cliente",
      description: "Redirecionado para o portal do cliente",
    });
  };

  const todayAppointments = [
    { time: "09:00", client: "Maria Silva", pet: "Rex (Golden)", service: "Consulta", status: "confirmado" },
    { time: "10:30", client: "João Santos", pet: "Mimi (Persa)", service: "Banho e Tosa", status: "em_andamento" },
    { time: "14:00", client: "Ana Costa", pet: "Thor (Labrador)", service: "Vacinação", status: "pendente" },
    { time: "15:30", client: "Carlos Lima", pet: "Luna (SRD)", service: "Castração", status: "confirmado" },
  ];

  const stats = [
    { title: "Agendamentos Hoje", value: "12", icon: Calendar, color: "text-primary", bg: "bg-primary/10" },
    { title: "Clientes Ativos", value: "248", icon: Users, color: "text-secondary", bg: "bg-secondary/10" },
    { title: "Pets Cadastrados", value: "456", icon: Heart, color: "text-accent", bg: "bg-accent/10" },
    { title: "Faturamento Mensal", value: "R$ 18.750", icon: DollarSign, color: "text-success", bg: "bg-success/10" },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmado": return "bg-success/20 text-success border-success/30";
      case "em_andamento": return "bg-warning/20 text-warning border-warning/30";
      case "pendente": return "bg-muted text-muted-foreground border-border";
      default: return "bg-muted text-muted-foreground border-border";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "confirmado": return "Confirmado";
      case "em_andamento": return "Em Andamento";
      case "pendente": return "Pendente";
      default: return status;
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-primary p-8 text-white">
        <div 
          className="absolute inset-0 opacity-20 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="relative z-10">
          <h1 className="text-3xl font-bold mb-2">Bem-vindo ao I Pet! 🐾</h1>
          <p className="text-lg opacity-90 mb-4">{today}</p>
          <p className="text-base opacity-80 max-w-2xl">
            Gerencie seu petshop de forma simples e eficiente. Acompanhe agendamentos, 
            clientes e o crescimento do seu negócio em um só lugar.
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index} className="hover:shadow-medium transition-all duration-300 hover:-translate-y-1">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                  <p className="text-2xl font-bold mt-1">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-lg ${stat.bg}`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Today's Appointments */}
        <Card className="lg:col-span-2 shadow-soft">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-primary" />
              Agendamentos de Hoje
            </CardTitle>
            <Button variant="outline" size="sm" onClick={() => navigate('/agendamentos')}>
              Ver Todos
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {todayAppointments.map((appointment, index) => (
                <div key={index} className="flex items-center justify-between p-4 rounded-lg border border-border hover:bg-muted/30 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="text-center">
                      <div className="text-lg font-semibold text-primary">{appointment.time}</div>
                    </div>
                    <div>
                      <p className="font-medium">{appointment.client}</p>
                      <p className="text-sm text-muted-foreground">{appointment.pet}</p>
                      <p className="text-sm text-secondary font-medium">{appointment.service}</p>
                    </div>
                  </div>
                  <Badge variant="outline" className={getStatusColor(appointment.status)}>
                    {getStatusText(appointment.status)}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle>Ações Rápidas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full justify-start bg-gradient-primary hover:opacity-90" size="lg" onClick={handleNovoAgendamento}>
              <Calendar className="mr-2 h-4 w-4" />
              Novo Agendamento
            </Button>
            <Button variant="outline" className="w-full justify-start" size="lg" onClick={handleCadastrarCliente}>
              <Users className="mr-2 h-4 w-4" />
              Cadastrar Cliente
            </Button>
            <Button variant="outline" className="w-full justify-start" size="lg" onClick={handleCadastrarPet}>
              <Heart className="mr-2 h-4 w-4" />
              Cadastrar Pet
            </Button>
            <Button variant="outline" className="w-full justify-start" size="lg" onClick={handleVerRelatorios}>
              <TrendingUp className="mr-2 h-4 w-4" />
              Ver Relatórios
            </Button>
            <Button variant="outline" className="w-full justify-start" size="lg" onClick={handlePortalCliente}>
              <ExternalLink className="mr-2 h-4 w-4" />
              Portal do Cliente
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="shadow-soft">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-primary mb-2">8</div>
            <p className="text-sm text-muted-foreground">Pets para Buscar Hoje</p>
          </CardContent>
        </Card>
        <Card className="shadow-soft">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-secondary mb-2">3</div>
            <p className="text-sm text-muted-foreground">Vacinações Pendentes</p>
          </CardContent>
        </Card>
        <Card className="shadow-soft">
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-accent mb-2">15%</div>
            <p className="text-sm text-muted-foreground">Crescimento Este Mês</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
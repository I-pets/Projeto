import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { LandingHeader } from '@/components/LandingHeader';
import { FeatureCard } from '@/components/FeatureCard';
import { FAQSection } from '@/components/FAQSection';
import { ChatWidget } from '@/components/ChatWidget';
import { 
  Calendar, 
  Users, 
  Smartphone, 
  BarChart3, 
  Clock, 
  Shield,
  CheckCircle,
  Star,
  ArrowRight,
  PawPrint,
  Zap,
  Heart,
  TrendingUp
} from 'lucide-react';

import dashboardMockup from '@/assets/dashboard-mockup.jpg';
import heroPetshop from '@/assets/hero-petshop.jpg';
import mobileMockup from '@/assets/mobile-mockup.jpg';
import petshopHero from '@/assets/petshop-hero.jpg';

const features = [
  {
    icon: Calendar,
    title: 'Agendamentos Inteligentes',
    description: 'Calendário avançado com drag & drop, lembretes automáticos e integração WhatsApp para nunca mais perder um cliente.',
    gradient: 'bg-gradient-primary'
  },
  {
    icon: Users,
    title: 'Gestão Completa de Clientes',
    description: 'Histórico detalhado de pets, vacinas, tratamentos e preferências. Tudo organizado em um só lugar.',
    gradient: 'bg-gradient-secondary'
  },
  {
    icon: Smartphone,
    title: 'Portal do Cliente',
    description: 'App exclusivo para clientes agendarem serviços, acompanharem seus pets e receberem notificações.',
    gradient: 'bg-gradient-warm'
  },
  {
    icon: BarChart3,
    title: 'Relatórios Avançados',
    description: 'Dashboards em tempo real com métricas de desempenho, faturamento e crescimento do seu negócio.',
    gradient: 'bg-gradient-primary'
  },
  {
    icon: Clock,
    title: 'Multi-Empresas',
    description: 'Gerencie múltiplos pet shops com dados isolados, configurações independentes e controle centralizado.',
    gradient: 'bg-gradient-secondary'
  },
  {
    icon: Shield,
    title: 'Segurança Total',
    description: 'Dados protegidos com criptografia avançada, backup automático na nuvem e conformidade com LGPD.',
    gradient: 'bg-gradient-warm'
  }
];

const benefits = [
  {
    icon: Zap,
    title: 'Economia de 4h por dia',
    description: 'Automatize tarefas repetitivas e foque no que realmente importa: cuidar dos pets.'
  },
  {
    icon: TrendingUp,
    title: 'Aumento de 35% na receita',
    description: 'Otimize sua agenda, reduza faltas e aumente a satisfação dos clientes.'
  },
  {
    icon: Heart,
    title: 'Clientes mais satisfeitos',
    description: 'Ofereça uma experiência premium com lembretes e acompanhamento personalizado.'
  }
];

const testimonials = [
  {
    name: 'Dr. Maria Silva',
    role: 'Veterinária - Pet Care Plus',
    text: 'O I-Pet transformou completamente nossa rotina. Agora conseguimos atender 40% mais clientes com muito menos estresse.',
    rating: 5
  },
  {
    name: 'João Pedro',
    role: 'Proprietário - PetShop Amor Animal',
    text: 'A facilidade para agendar e o controle financeiro são incríveis. Recomendo para todos os colegas do setor.',
    rating: 5
  }
];

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      <LandingHeader />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in">
              <h1 className="text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
                Transforme seu
                <span className="bg-gradient-primary bg-clip-text text-transparent"> Pet Shop </span>
                com tecnologia
              </h1>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                Sistema completo de agendamentos, gestão de clientes e controle financeiro 
                para pet shops modernos. Simplifique sua rotina e multiplique seus resultados.
              </p>
              
              {/* Stats */}
              <div className="flex flex-col sm:flex-row gap-6 mb-8">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-success" />
                  <span className="text-foreground font-medium">Teste grátis por 14 dias</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-success" />
                  <span className="text-foreground font-medium">Sem compromisso</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-success" />
                  <span className="text-foreground font-medium">Suporte completo</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/login">
                  <Button size="lg" className="text-lg px-8 w-full sm:w-auto">
                    Começar Teste Grátis
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Button size="lg" variant="outline" className="text-lg px-8 w-full sm:w-auto">
                  Ver Demonstração
                </Button>
              </div>
            </div>
            
            <div className="relative animate-fade-in">
              <img 
                src={dashboardMockup} 
                alt="Dashboard I-Pet" 
                className="w-full h-auto rounded-2xl shadow-strong"
              />
              <div className="absolute inset-0 bg-gradient-primary/10 rounded-2xl"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-12 bg-muted/30">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground mb-6">Mais de 500 pet shops já confiam no I-Pet</p>
          <div className="flex justify-center items-center gap-8 opacity-60">
            <div className="w-24 h-12 bg-muted rounded flex items-center justify-center">
              <PawPrint className="h-6 w-6" />
            </div>
            <div className="w-24 h-12 bg-muted rounded flex items-center justify-center">
              <Heart className="h-6 w-6" />
            </div>
            <div className="w-24 h-12 bg-muted rounded flex items-center justify-center">
              <Star className="h-6 w-6" />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="funcionalidades" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-4xl font-bold text-foreground mb-4">
              Tudo que você precisa em um só lugar
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Ferramentas profissionais para revolucionar a gestão do seu pet shop
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <FeatureCard {...feature} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Product Demo Section */}
      <section id="demonstracao" className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="animate-fade-in">
              <h2 className="text-4xl font-bold text-foreground mb-6">
                Interface moderna e intuitiva
              </h2>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                Dashboard completo com todas as informações que você precisa. 
                Visualize agendamentos, acompanhe receitas e gerencie sua equipe 
                de forma simples e eficiente.
              </p>
              <ul className="space-y-4">
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-primary mr-4" />
                  <span className="text-foreground">Calendário com drag & drop</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-primary mr-4" />
                  <span className="text-foreground">Notificações em tempo real</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-primary mr-4" />
                  <span className="text-foreground">Relatórios personalizáveis</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-primary mr-4" />
                  <span className="text-foreground">Backup automático na nuvem</span>
                </li>
              </ul>
            </div>
            <div className="relative animate-fade-in">
              <img 
                src={heroPetshop} 
                alt="Interface do Sistema" 
                className="w-full h-auto rounded-2xl shadow-strong"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="beneficios" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-4xl font-bold text-foreground mb-4">
              Resultados que você pode medir
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Veja o impacto real do I-Pet no seu negócio
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center p-8 border-border/50 hover:shadow-medium transition-all animate-fade-in">
                <CardContent className="pt-6">
                  <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-6">
                    <benefit.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-foreground mb-3">{benefit.title}</h3>
                  <p className="text-muted-foreground">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-4xl font-bold text-foreground mb-4">
              O que nossos clientes dizem
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="p-8 border-border/50 animate-fade-in">
                <CardContent className="pt-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-warning fill-current" />
                    ))}
                  </div>
                  <p className="text-foreground mb-6 text-lg leading-relaxed">"{testimonial.text}"</p>
                  <div>
                    <p className="font-semibold text-foreground">{testimonial.name}</p>
                    <p className="text-muted-foreground">{testimonial.role}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Mobile App Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="order-2 lg:order-1 relative max-w-md mx-auto animate-fade-in">
              <img 
                src={mobileMockup} 
                alt="App Mobile I-Pet" 
                className="w-full h-auto rounded-3xl shadow-strong"
              />
            </div>
            <div className="order-1 lg:order-2 animate-fade-in">
              <h2 className="text-4xl font-bold text-foreground mb-6">
                App mobile para seus clientes
              </h2>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                Seus clientes podem agendar serviços, receber notificações e 
                acompanhar o histórico dos seus pets direto pelo celular.
              </p>
              <ul className="space-y-4">
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-secondary mr-4" />
                  <span className="text-foreground">Agendamento online 24/7</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-secondary mr-4" />
                  <span className="text-foreground">Histórico completo de serviços</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-secondary mr-4" />
                  <span className="text-foreground">Lembretes de vacinas</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-secondary mr-4" />
                  <span className="text-foreground">Notificações push</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection />

      {/* Final CTA */}
      <section id="contato" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center bg-gradient-primary rounded-3xl p-16 text-white animate-fade-in">
            <h2 className="text-4xl font-bold mb-6">
              Pronto para revolucionar seu pet shop?
            </h2>
            <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
              Junte-se a centenas de pet shops que já usam o I-Pet para 
              gerenciar seus negócios de forma mais eficiente e lucrativa.
            </p>
            
            <div className="flex flex-col items-center gap-6 mb-8">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/login">
                  <Button size="lg" variant="secondary" className="text-lg px-8 w-full sm:w-auto">
                    Começar Teste Grátis
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Button size="lg" variant="outline" className="text-lg px-8 border-white text-white hover:bg-white hover:text-primary w-full sm:w-auto">
                  Falar com Especialista
                </Button>
              </div>
              
              <div className="flex items-center gap-6 text-sm opacity-80">
                <span>✓ 14 dias grátis</span>
                <span>✓ Sem cartão de crédito</span>
                <span>✓ Suporte incluído</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t border-border bg-muted/30">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
                  <PawPrint className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-primary">I Pet</h3>
                </div>
              </div>
              <p className="text-muted-foreground">
                O sistema completo para gestão de pet shops modernos.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-4">Produto</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#funcionalidades" className="hover:text-foreground">Funcionalidades</a></li>
                <li><a href="#" className="hover:text-foreground">Preços</a></li>
                <li><a href="#" className="hover:text-foreground">FAQ</a></li>
                <li><a href="#" className="hover:text-foreground">Demonstração ao Vivo</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-4">Suporte</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Central de Ajuda</a></li>
                <li><a href="#contato" className="hover:text-foreground">Contato</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground mb-4">Empresa</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Sobre</a></li>
                <li><a href="#" className="hover:text-foreground">Privacidade</a></li>
                <li><a href="#" className="hover:text-foreground">Termos de Uso</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2024 I Pet. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>

      {/* Chat Widget */}
      <ChatWidget />
    </div>
  );
}

import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Heart, MapPin, User, Phone, Mail, Settings, ArrowLeft, Bell, TrendingUp, Activity, Star, Sparkles, Home, CalendarDays, History, UserCircle, Menu, X, ChevronRight, PawPrint } from "lucide-react";
import { PetForm } from "@/components/PetForm";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useNavigate } from "react-router-dom";
import AppointmentCalendar from "@/components/AppointmentCalendar";
import NotificationCenter from "@/components/NotificationCenter";

interface Pet {
  nome: string;
  especie: string;
  raca: string;
  idade: string;
  peso: string;
  cor: string;
  observacoesMedicas: string;
}

interface AppointmentData {
  id: string;
  pet: string;
  service: string;
  date: string;
  time: string;
  status: "agendado" | "confirmado" | "concluido" | "cancelado";
  value: number;
  notes?: string;
}

// Mock data para demonstração
const mockClient = {
  name: "Maria Silva",
  email: "maria.silva@email.com",
  phone: "(11) 99999-9999",
  address: "Rua das Flores, 123 - São Paulo, SP",
  memberSince: "2023-01-15",
  pets: [
    {
      nome: "Rex",
      especie: "Cachorro",
      raca: "Golden Retriever",
      idade: "3 anos",
      peso: "25kg",
      cor: "Dourado",
      observacoesMedicas: "Muito brincalhão e sociável"
    },
    {
      nome: "Mimi",
      especie: "Gato",
      raca: "Siamês",
      idade: "2 anos",
      peso: "4kg",
      cor: "Creme",
      observacoesMedicas: "Gosta de carinho na barriga"
    }
  ]
};

const mockAppointments: AppointmentData[] = [
  {
    id: "1",
    pet: "Rex",
    service: "Banho e Tosa",
    date: "2024-01-20",
    time: "10:00",
    status: "agendado",
    value: 80.00
  },
  {
    id: "2",
    pet: "Mimi",
    service: "Consulta Veterinária",
    date: "2024-01-18",
    time: "14:30",
    status: "concluido",
    value: 150.00
  },
  {
    id: "3",
    pet: "Rex",
    service: "Vacinação",
    date: "2024-01-15",
    time: "09:00",
    status: "concluido",
    value: 120.00
  }
];

const services = [
  { id: "banho-tosa", name: "Banho e Tosa", price: 80 },
  { id: "consulta-vet", name: "Consulta Veterinária", price: 150 },
  { id: "vacinacao", name: "Vacinação", price: 120 },
  { id: "cirurgia", name: "Cirurgia", price: 500 },
  { id: "exame", name: "Exame Laboratorial", price: 80 }
];

const Portal = () => {
  const [pets, setPets] = useState<Pet[]>(mockClient.pets);
  const [appointments, setAppointments] = useState<AppointmentData[]>(mockAppointments);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [historyFilter, setHistoryFilter] = useState("todos");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [newAppointment, setNewAppointment] = useState({
    pet: "",
    service: "",
    date: undefined as Date | undefined,
    time: "",
    notes: ""
  });
  const [clientData, setClientData] = useState(mockClient);
  const { toast } = useToast();
  const navigate = useNavigate();

  // Detect mobile for swipe functionality
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;
    
    const tabs = ["dashboard", "agenda", "pets", "historico", "perfil"];
    const currentIndex = tabs.indexOf(activeTab);
    
    if (isLeftSwipe && currentIndex < tabs.length - 1) {
      setActiveTab(tabs[currentIndex + 1]);
    }
    if (isRightSwipe && currentIndex > 0) {
      setActiveTab(tabs[currentIndex - 1]);
    }
  };

  const tabIcons = {
    dashboard: Home,
    agenda: CalendarDays,
    pets: PawPrint,
    historico: History,
    perfil: UserCircle
  };

  const tabLabels = {
    dashboard: "Home",
    agenda: "Agendar",
    pets: "Pets",
    historico: "Histórico",
    perfil: "Perfil"
  };

  const handleNewAppointment = () => {
    if (!newAppointment.pet || !newAppointment.service || !newAppointment.date || !newAppointment.time) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos obrigatórios",
        variant: "destructive"
      });
      return;
    }

    const service = services.find(s => s.id === newAppointment.service);
    
    const appointment: AppointmentData = {
      id: Date.now().toString(),
      pet: newAppointment.pet,
      service: service?.name || newAppointment.service,
      date: format(newAppointment.date, "yyyy-MM-dd"),
      time: newAppointment.time,
      status: "agendado",
      value: service?.price || 0,
      notes: newAppointment.notes
    };

    setAppointments([...appointments, appointment]);
    setNewAppointment({
      pet: "",
      service: "",
      date: undefined,
      time: "",
      notes: ""
    });

    toast({
      title: "Agendamento realizado!",
      description: `Seu agendamento para ${appointment.pet} foi confirmado para ${format(newAppointment.date, "dd/MM/yyyy", { locale: ptBR })} às ${appointment.time}`,
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "agendado": return "bg-blue-500";
      case "confirmado": return "bg-green-500";
      case "concluido": return "bg-gray-500";
      case "cancelado": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "agendado": return "Agendado";
      case "confirmado": return "Confirmado";
      case "concluido": return "Concluído";
      case "cancelado": return "Cancelado";
      default: return status;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-accent/5 to-primary/5 touch-manipulation">
      {/* Mobile Header */}
      <header className="bg-white/90 backdrop-blur-md shadow-sm border-b sticky top-0 z-50">
        <div className="px-4 sm:px-6">
          <div className="flex justify-between items-center h-14 md:h-16">
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate("/")}
                className="text-muted-foreground hover:text-foreground w-10 h-10"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div className="hidden sm:block">
                <h1 className="text-lg md:text-xl font-semibold text-foreground">Portal do Cliente</h1>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium text-foreground">{clientData.name}</p>
                <p className="text-xs text-muted-foreground">Cliente desde {format(new Date(clientData.memberSince), "MMM yyyy", { locale: ptBR })}</p>
              </div>
              <Avatar className="h-10 w-10">
                <AvatarImage src="" alt={clientData.name} />
                <AvatarFallback className="bg-primary/10 text-primary font-medium">
                  {clientData.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </header>

      {/* Welcome Section - Mobile-first */}
      <div className="bg-gradient-to-r from-primary to-secondary text-white px-4 py-6 sm:px-6 md:hidden">
        <div className="text-center">
          <h1 className="text-xl font-bold mb-1">Olá, {clientData.name.split(" ")[0]}!</h1>
          <p className="text-primary-foreground/80 text-sm">
            Bem-vindo(a) ao seu portal pet 🐾
          </p>
        </div>
      </div>

      {/* Main Content */}
      <main 
        className="px-4 sm:px-6 pb-20 max-w-7xl mx-auto"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <Tabs defaultValue="dashboard" value={activeTab} onValueChange={setActiveTab} className="w-full">
          {/* Mobile Tab Navigation - Bottom Fixed */}
          <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t z-50 sm:hidden">
            <div className="grid grid-cols-5 px-2 py-2">
              {Object.entries(tabLabels).map(([key, label]) => {
                const IconComponent = tabIcons[key as keyof typeof tabIcons];
                return (
                  <button
                    key={key}
                    onClick={() => setActiveTab(key)}
                    className={`flex flex-col items-center p-2 rounded-xl transition-all duration-200 ${
                      activeTab === key 
                        ? 'bg-primary text-white scale-105' 
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    <IconComponent className="h-6 w-6 mb-1" />
                    <span className="text-xs font-medium">{label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Desktop Tab Navigation */}
          <div className="hidden sm:block sticky top-20 z-40 mb-6">
            <TabsList className="grid w-full grid-cols-5 h-12 bg-white/90 backdrop-blur-md">
              {Object.entries(tabLabels).map(([key, label]) => {
                const IconComponent = tabIcons[key as keyof typeof tabIcons];
                return (
                  <TabsTrigger 
                    key={key}
                    value={key}
                    className="flex items-center space-x-2 h-full data-[state=active]:bg-primary data-[state=active]:text-white"
                  >
                    <IconComponent className="h-4 w-4" />
                    <span className="hidden md:inline">{label}</span>
                  </TabsTrigger>
                );
              })}
            </TabsList>
          </div>

          {/* Dashboard */}
          <TabsContent value="dashboard" className="space-y-4 md:space-y-6 py-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {/* Estatísticas com design mobile-first */}
              <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Próximos</p>
                      <p className="text-2xl font-bold text-primary">
                        {appointments.filter(app => app.status === "agendado" || app.status === "confirmado").length}
                      </p>
                      <p className="text-xs text-muted-foreground">Agendamentos</p>
                    </div>
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                      <Calendar className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-secondary/10 to-secondary/5 border-secondary/20">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Meus</p>
                      <p className="text-2xl font-bold text-secondary">{pets.length}</p>
                      <p className="text-xs text-muted-foreground">Pets</p>
                    </div>
                    <div className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center">
                      <Heart className="h-6 w-6 text-secondary" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-accent/10 to-accent/5 border-accent/20 sm:col-span-2 md:col-span-1">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Total</p>
                      <p className="text-2xl font-bold text-accent">
                        R$ {appointments.reduce((sum, app) => sum + app.value, 0).toFixed(2)}
                      </p>
                      <p className="text-xs text-muted-foreground">Investido</p>
                    </div>
                    <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
                      <TrendingUp className="h-6 w-6 text-accent" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Ações Rápidas - Mobile-first */}
            <Card className="bg-gradient-to-r from-primary/5 to-secondary/5">
              <CardContent className="p-4">
                <h3 className="font-semibold text-lg mb-4 text-center">Ações Rápidas</h3>
                <div className="grid grid-cols-2 gap-3">
                  <Button 
                    onClick={() => setActiveTab("agenda")}
                    className="h-16 flex flex-col items-center justify-center space-y-2 bg-primary hover:bg-primary/90"
                  >
                    <CalendarDays className="h-6 w-6" />
                    <span className="text-sm">Agendar</span>
                  </Button>
                  <Button 
                    onClick={() => setActiveTab("pets")}
                    variant="outline"
                    className="h-16 flex flex-col items-center justify-center space-y-2 border-secondary text-secondary hover:bg-secondary/10"
                  >
                    <PawPrint className="h-6 w-6" />
                    <span className="text-sm">Meus Pets</span>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Próximos Agendamentos */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bell className="h-5 w-5 mr-2" />
                  Próximos Agendamentos
                </CardTitle>
                <CardDescription>
                  Seus agendamentos confirmados
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {appointments.filter(app => app.status === "agendado" || app.status === "confirmado").slice(0, 3).map((appointment) => (
                    <div key={appointment.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                          <Heart className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{appointment.pet}</p>
                          <p className="text-sm text-muted-foreground">{appointment.service}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{format(new Date(appointment.date), "dd/MM", { locale: ptBR })}</p>
                        <p className="text-sm text-muted-foreground">{appointment.time}</p>
                      </div>
                    </div>
                  ))}
                  {appointments.filter(app => app.status === "agendado" || app.status === "confirmado").length === 0 && (
                    <div className="text-center py-8">
                      <Activity className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                      <p className="text-muted-foreground">Nenhum agendamento próximo</p>
                      <Button variant="outline" className="mt-4" onClick={() => setActiveTab("agenda")}>
                        Agendar Serviço
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Notificações */}
            <NotificationCenter appointments={appointments} />

            {/* Histórico Recente */}
            <Card>
              <CardHeader>
                <CardTitle>Histórico Recente</CardTitle>
                <CardDescription>
                  Últimos serviços realizados
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {appointments.filter(app => app.status === "concluido").slice(0, 3).map((appointment) => (
                    <div key={appointment.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                          <Heart className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium">{appointment.pet}</p>
                          <p className="text-sm text-muted-foreground">{appointment.service}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">R$ {appointment.value.toFixed(2)}</p>
                        <p className="text-sm text-muted-foreground">{format(new Date(appointment.date), "dd/MM", { locale: ptBR })}</p>
                      </div>
                    </div>
                  ))}
                  {appointments.filter(app => app.status === "concluido").length === 0 && (
                    <p className="text-center text-muted-foreground py-4">
                      Nenhum serviço realizado ainda
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Agendamento */}
          <TabsContent value="agenda" className="space-y-4 py-4">
            <Card className="bg-gradient-to-br from-primary/5 to-secondary/5">
              <CardHeader className="pb-4">
                <CardTitle className="text-center text-lg">Agendar Novo Serviço</CardTitle>
                <CardDescription className="text-center">
                  Escolha o pet, serviço e horário desejado
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <Label htmlFor="pet" className="text-base font-medium">Pet *</Label>
                    <Select value={newAppointment.pet} onValueChange={(value) => setNewAppointment({...newAppointment, pet: value})}>
                      <SelectTrigger className="h-12 text-base">
                        <SelectValue placeholder="Selecione o pet" />
                      </SelectTrigger>
                      <SelectContent>
                        {pets.map((pet, index) => (
                          <SelectItem key={index} value={pet.nome} className="p-3">
                            <div className="flex items-center space-x-3">
                              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                                <PawPrint className="h-4 w-4 text-primary" />
                              </div>
                              <div>
                                <p className="font-medium">{pet.nome}</p>
                                <p className="text-sm text-muted-foreground">{pet.especie}</p>
                              </div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="service" className="text-base font-medium">Serviço *</Label>
                    <Select value={newAppointment.service} onValueChange={(value) => setNewAppointment({...newAppointment, service: value})}>
                      <SelectTrigger className="h-12 text-base">
                        <SelectValue placeholder="Selecione o serviço" />
                      </SelectTrigger>
                      <SelectContent>
                        {services.map((service) => (
                          <SelectItem key={service.id} value={service.id} className="p-3">
                            <div className="flex items-center justify-between w-full">
                              <span className="font-medium">{service.name}</span>
                              <span className="text-primary font-bold">R$ {service.price.toFixed(2)}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Calendário Visual */}
                <div className="space-y-4">
                  <div>
                    <Label className="text-base font-medium">Data e Horário *</Label>
                    <p className="text-sm text-muted-foreground">
                      Selecione a data e horário desejados
                    </p>
                  </div>
                  <AppointmentCalendar
                    selectedDate={newAppointment.date}
                    selectedTime={newAppointment.time}
                    onDateSelect={(date) => setNewAppointment({...newAppointment, date})}
                    onTimeSelect={(time) => setNewAppointment({...newAppointment, time})}
                    existingAppointments={appointments.map(app => ({
                      date: app.date,
                      time: app.time
                    }))}
                  />
                </div>

                <div>
                  <Label htmlFor="notes" className="text-base font-medium">Observações</Label>
                  <Textarea
                    id="notes"
                    placeholder="Alguma observação especial..."
                    value={newAppointment.notes}
                    onChange={(e) => setNewAppointment({...newAppointment, notes: e.target.value})}
                    className="min-h-[100px] text-base"
                  />
                </div>

                <Button 
                  onClick={handleNewAppointment} 
                  className="w-full h-14 text-base font-semibold bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
                >
                  <Calendar className="h-5 w-5 mr-2" />
                  Agendar Serviço
                </Button>
              </CardContent>
            </Card>

            {/* Próximos Agendamentos */}
            <Card>
              <CardHeader>
                <CardTitle>Próximos Agendamentos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {appointments.filter(app => app.status === "agendado" || app.status === "confirmado").map((appointment) => (
                    <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="flex flex-col">
                          <div className="flex items-center space-x-2">
                            <Heart className="h-4 w-4 text-primary" />
                            <span className="font-medium">{appointment.pet}</span>
                          </div>
                          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                            <Calendar className="h-3 w-3" />
                            <span>{format(new Date(appointment.date), "dd/MM/yyyy", { locale: ptBR })}</span>
                            <Clock className="h-3 w-3 ml-2" />
                            <span>{appointment.time}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{appointment.service}</p>
                        <Badge className={getStatusColor(appointment.status)}>
                          {getStatusLabel(appointment.status)}
                        </Badge>
                      </div>
                    </div>
                  ))}
                  {appointments.filter(app => app.status === "agendado" || app.status === "confirmado").length === 0 && (
                    <p className="text-center text-muted-foreground py-8">
                      Nenhum agendamento próximo
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Meus Pets */}
          <TabsContent value="pets" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Meus Pets</CardTitle>
                <CardDescription>
                  Gerencie as informações dos seus pets
                </CardDescription>
              </CardHeader>
              <CardContent>
                <PetForm pets={pets} onChange={setPets} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Histórico */}
          <TabsContent value="historico" className="space-y-4 py-4">
            <Card className="bg-gradient-to-br from-primary/5 to-secondary/5">
              <CardHeader className="pb-4">
                <CardTitle className="text-center text-lg">Histórico de Serviços</CardTitle>
                <CardDescription className="text-center">
                  Veja todos os serviços realizados
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Filtros Mobile-friendly */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <Button
                      variant={historyFilter === "todos" ? "default" : "outline"}
                      size="lg"
                      className="h-12 text-base"
                      onClick={() => setHistoryFilter("todos")}
                    >
                      Todos
                    </Button>
                    <Button
                      variant={historyFilter === "concluido" ? "default" : "outline"}
                      size="lg"
                      className="h-12 text-base bg-success/10 hover:bg-success/20 text-success border-success/20"
                      onClick={() => setHistoryFilter("concluido")}
                    >
                      Concluídos
                    </Button>
                    <Button
                      variant={historyFilter === "agendado" ? "default" : "outline"}
                      size="lg"
                      className="h-12 text-base bg-primary/10 hover:bg-primary/20 text-primary border-primary/20"
                      onClick={() => setHistoryFilter("agendado")}
                    >
                      Agendados
                    </Button>
                    <Button
                      variant={historyFilter === "cancelado" ? "default" : "outline"}
                      size="lg"
                      className="h-12 text-base bg-destructive/10 hover:bg-destructive/20 text-destructive border-destructive/20"
                      onClick={() => setHistoryFilter("cancelado")}
                    >
                      Cancelados
                    </Button>
                  </div>

                  {/* Lista de Agendamentos Mobile-first */}
                  <div className="space-y-3">
                    {appointments
                      .filter(app => historyFilter === "todos" || app.status === historyFilter)
                      .map((appointment) => (
                        <Card key={appointment.id} className="bg-white/60 border-l-4 border-l-primary/30">
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                                  <PawPrint className="h-6 w-6 text-primary" />
                                </div>
                                <div>
                                  <p className="font-semibold text-base">{appointment.pet}</p>
                                  <p className="text-sm text-muted-foreground">{appointment.service}</p>
                                  <div className="flex items-center space-x-2 text-xs text-muted-foreground mt-1">
                                    <Calendar className="h-3 w-3" />
                                    <span>{format(new Date(appointment.date), "dd/MM/yyyy", { locale: ptBR })}</span>
                                    <Clock className="h-3 w-3 ml-2" />
                                    <span>{appointment.time}</span>
                                  </div>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="font-bold text-lg text-primary">R$ {appointment.value.toFixed(2)}</p>
                                <Badge className={`${getStatusColor(appointment.status)} text-white`}>
                                  {getStatusLabel(appointment.status)}
                                </Badge>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    {appointments.filter(app => historyFilter === "todos" || app.status === historyFilter).length === 0 && (
                      <div className="text-center py-12">
                        <History className="h-16 w-16 mx-auto text-muted-foreground/50 mb-4" />
                        <p className="text-muted-foreground text-lg">
                          Nenhum agendamento encontrado para o filtro selecionado
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Perfil */}
          <TabsContent value="perfil" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Meu Perfil</CardTitle>
                <CardDescription>
                  Atualize suas informações pessoais
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Nome Completo</Label>
                    <Input
                      id="name"
                      value={clientData.name}
                      onChange={(e) => setClientData({...clientData, name: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="email">E-mail</Label>
                    <Input
                      id="email"
                      type="email"
                      value={clientData.email}
                      onChange={(e) => setClientData({...clientData, email: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone">Telefone</Label>
                    <Input
                      id="phone"
                      value={clientData.phone}
                      onChange={(e) => setClientData({...clientData, phone: e.target.value})}
                    />
                  </div>

                  <div>
                    <Label htmlFor="address">Endereço</Label>
                    <Input
                      id="address"
                      value={clientData.address}
                      onChange={(e) => setClientData({...clientData, address: e.target.value})}
                    />
                  </div>
                </div>

                <Separator />

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <Heart className="h-8 w-8 text-primary mx-auto mb-2" />
                        <p className="text-2xl font-bold">{pets.length}</p>
                        <p className="text-sm text-muted-foreground">Pets Cadastrados</p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <Calendar className="h-8 w-8 text-primary mx-auto mb-2" />
                        <p className="text-2xl font-bold">{appointments.length}</p>
                        <p className="text-sm text-muted-foreground">Total de Visitas</p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <Settings className="h-8 w-8 text-primary mx-auto mb-2" />
                        <p className="text-2xl font-bold">
                          R$ {appointments.reduce((sum, app) => sum + app.value, 0).toFixed(2)}
                        </p>
                        <p className="text-sm text-muted-foreground">Valor Total</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline">
                    Cancelar
                  </Button>
                  <Button onClick={() => toast({ title: "Perfil atualizado com sucesso!" })}>
                    Salvar Alterações
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Portal;
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Calendar, Users, Smartphone, BarChart3, Clock, Shield } from "lucide-react";
import { useNavigate } from "react-router-dom";
import heroImage from "@/assets/hero-petshop.jpg";
import dashboardMockup from "@/assets/dashboard-mockup.jpg";
import mobileMockup from "@/assets/mobile-mockup.jpg";

const Index = () => {
  const navigate = useNavigate();

  const handleStartNow = () => {
    navigate("/agendamentos");
  };

  const handleViewDemo = () => {
    navigate("/dashboard");
  };

  const handleTalkToSales = () => {
    navigate("/configuracoes");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Header */}
      <header className="container mx-auto px-4 py-6">
        <nav className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-primary rounded-lg"></div>
            <span className="text-2xl font-bold text-foreground">PetFlow</span>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" onClick={() => navigate("/portal")}>Login</Button>
            <Button onClick={handleStartNow}>Teste Grátis</Button>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
              Gerencie seu
              <span className="bg-gradient-primary bg-clip-text text-transparent"> Pet Shop </span>
              com facilidade
            </h1>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Sistema completo de agendamentos, controle de clientes e gestão financeira 
              para pet shops modernos. Simplifique sua rotina e aumente sua produtividade.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="text-lg px-8" onClick={handleStartNow}>
                Começar Agora
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8" onClick={handleViewDemo}>
                Ver Demo
              </Button>
            </div>
          </div>
          <div className="relative">
            <img 
              src={heroImage} 
              alt="Pet Shop Profissional" 
              className="w-full h-auto rounded-2xl shadow-strong"
            />
            <div className="absolute inset-0 bg-gradient-primary/10 rounded-2xl"></div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Tudo que você precisa em um só lugar
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Ferramentas profissionais para transformar a gestão do seu pet shop
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="group hover:shadow-medium transition-all duration-300 border-border/50">
            <CardContent className="p-8">
              <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Calendar className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-2xl font-semibold text-foreground mb-4">Agendamentos Inteligentes</h3>
              <p className="text-muted-foreground leading-relaxed">
                Calendário avançado com drag & drop, lembretes automáticos e integração WhatsApp.
              </p>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-medium transition-all duration-300 border-border/50">
            <CardContent className="p-8">
              <div className="w-12 h-12 bg-gradient-secondary rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Users className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-2xl font-semibold text-foreground mb-4">Gestão de Clientes</h3>
              <p className="text-muted-foreground leading-relaxed">
                Histórico completo de pets, vacinas, tratamentos e preferências dos clientes.
              </p>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-medium transition-all duration-300 border-border/50">
            <CardContent className="p-8">
              <div className="w-12 h-12 bg-gradient-warm rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <BarChart3 className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-2xl font-semibold text-foreground mb-4">Relatórios Avançados</h3>
              <p className="text-muted-foreground leading-relaxed">
                Dashboards em tempo real com métricas de desempenho e crescimento do negócio.
              </p>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-medium transition-all duration-300 border-border/50">
            <CardContent className="p-8">
              <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Smartphone className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-2xl font-semibold text-foreground mb-4">Portal do Cliente</h3>
              <p className="text-muted-foreground leading-relaxed">
                App exclusivo para clientes agendarem serviços e acompanharem seus pets.
              </p>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-medium transition-all duration-300 border-border/50">
            <CardContent className="p-8">
              <div className="w-12 h-12 bg-gradient-secondary rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Clock className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-2xl font-semibold text-foreground mb-4">Multi-Empresas</h3>
              <p className="text-muted-foreground leading-relaxed">
                Gerencie múltiplos pet shops com dados isolados e configurações independentes.
              </p>
            </CardContent>
          </Card>

          <Card className="group hover:shadow-medium transition-all duration-300 border-border/50">
            <CardContent className="p-8">
              <div className="w-12 h-12 bg-gradient-warm rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-2xl font-semibold text-foreground mb-4">Segurança Total</h3>
              <p className="text-muted-foreground leading-relaxed">
                Dados protegidos com criptografia e backup automático na nuvem.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* System Demo Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl font-bold text-foreground mb-6">
              Interface moderna e intuitiva
            </h2>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Dashboard completo com todas as informações que você precisa. 
              Visualize agendamentos, acompanhe receitas e gerencie sua equipe 
              de forma simples e eficiente.
            </p>
            <ul className="space-y-4">
              <li className="flex items-center">
                <div className="w-2 h-2 bg-primary rounded-full mr-4"></div>
                <span className="text-foreground">Calendário com drag & drop</span>
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-primary rounded-full mr-4"></div>
                <span className="text-foreground">Notificações em tempo real</span>
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-primary rounded-full mr-4"></div>
                <span className="text-foreground">Relatórios personalizáveis</span>
              </li>
            </ul>
          </div>
          <div className="relative">
            <img 
              src={dashboardMockup} 
              alt="Dashboard do Sistema" 
              className="w-full h-auto rounded-2xl shadow-strong"
            />
          </div>
        </div>
      </section>

      {/* Mobile App Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="order-2 lg:order-1 relative max-w-md mx-auto">
            <img 
              src={mobileMockup} 
              alt="App Mobile" 
              className="w-full h-auto rounded-3xl shadow-strong"
            />
          </div>
          <div className="order-1 lg:order-2">
            <h2 className="text-4xl font-bold text-foreground mb-6">
              App mobile para seus clientes
            </h2>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Seus clientes podem agendar serviços, receber notificações e 
              acompanhar o histórico dos seus pets direto pelo celular.
            </p>
            <ul className="space-y-4">
              <li className="flex items-center">
                <div className="w-2 h-2 bg-secondary rounded-full mr-4"></div>
                <span className="text-foreground">Agendamento online 24/7</span>
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-secondary rounded-full mr-4"></div>
                <span className="text-foreground">Histórico completo de serviços</span>
              </li>
              <li className="flex items-center">
                <div className="w-2 h-2 bg-secondary rounded-full mr-4"></div>
                <span className="text-foreground">Lembretes de vacinas</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center bg-gradient-primary rounded-3xl p-16 text-white">
          <h2 className="text-4xl font-bold mb-6">
            Pronto para transformar seu pet shop?
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Junte-se a centenas de pet shops que já usam o PetFlow para 
            gerenciar seus negócios de forma mais eficiente.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" className="text-lg px-8" onClick={handleStartNow}>
              Começar Teste Grátis
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 border-white text-white hover:bg-white hover:text-primary" onClick={handleTalkToSales}>
              Falar com Vendas
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="container mx-auto px-4 py-12 border-t border-border">
        <div className="text-center text-muted-foreground">
          <p>&copy; 2024 PetFlow. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;